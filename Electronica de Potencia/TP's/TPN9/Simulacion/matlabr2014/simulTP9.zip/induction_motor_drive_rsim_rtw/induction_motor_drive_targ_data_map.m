  function targMap = targDataMap(),

  ;%***********************
  ;% Create Parameter Map *
  ;%***********************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 2;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc paramMap
    ;%
    paramMap.nSections           = nTotSects;
    paramMap.sectIdxOffset       = sectIdxOffset;
      paramMap.sections(nTotSects) = dumSection; %prealloc
    paramMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtP)
    ;%
      section.nData     = 105;
      section.data(105)  = dumData; %prealloc
      
	  ;% rtP.Fourier_f1
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtP.Fourier_n
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtP.Constant1_Value
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtP.u2_Value
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtP.Integrator_IC
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 5;
	
	  ;% rtP.u1_Value
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 6;
	
	  ;% rtP.LookupTable_XData
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 8;
	
	  ;% rtP.LookupTable_YData
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 10;
	
	  ;% rtP.u1_Value_b
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 12;
	
	  ;% rtP.u5_Value
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 28;
	
	  ;% rtP.u1_Value_f
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 44;
	
	  ;% rtP.TT1e6s_Gain
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 60;
	
	  ;% rtP.vqrvdr_Y0
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 61;
	
	  ;% rtP.vqsvds_Y0
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 62;
	
	  ;% rtP.vqrvdr_Y0_h
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 63;
	
	  ;% rtP.vqsvds_Y0_g
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 64;
	
	  ;% rtP.vqrvdr_Y0_m
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 65;
	
	  ;% rtP.vqsvds_Y0_h
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 66;
	
	  ;% rtP.irairb_Y0
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 67;
	
	  ;% rtP.isaisb_Y0
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 68;
	
	  ;% rtP.irairb_Y0_k
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 69;
	
	  ;% rtP.isaisb_Y0_n
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 70;
	
	  ;% rtP.irairb_Y0_j
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 71;
	
	  ;% rtP.isaisb_Y0_c
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 72;
	
	  ;% rtP.sinbetacosbetasinthcosth_Y0
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 73;
	
	  ;% rtP.W_Y0
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 74;
	
	  ;% rtP.we_Value
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 75;
	
	  ;% rtP.Gain2_Gain
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 76;
	
	  ;% rtP.web_psb_Gain
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 77;
	
	  ;% rtP.u3_Value
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 78;
	
	  ;% rtP.sinthrcosthr_Y0
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 94;
	
	  ;% rtP.W_Y0_d
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 95;
	
	  ;% rtP.Constant_Value
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 96;
	
	  ;% rtP.Gain1_Gain
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 98;
	
	  ;% rtP.u1_Value_e
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 99;
	
	  ;% rtP.sinthrcosthr_Y0_f
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 115;
	
	  ;% rtP.Constant_Value_c
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 116;
	
	  ;% rtP.Gain3_Gain
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 118;
	
	  ;% rtP.u4_Value
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 119;
	
	  ;% rtP.Rotorspeedwm_IC
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 135;
	
	  ;% rtP.Integrator_IC_o
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 136;
	
	  ;% rtP.Constant_Value_i
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 140;
	
	  ;% rtP.Constant1_Value_o
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 141;
	
	  ;% rtP.Constant2_Value
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 142;
	
	  ;% rtP.Switch_Threshold
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 158;
	
	  ;% rtP.u_Gain
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 159;
	
	  ;% rtP.Rotoranglethetam_IC
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 161;
	
	  ;% rtP.p_Gain
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 162;
	
	  ;% rtP.Gain_Gain
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 163;
	
	  ;% rtP.FromWs_Time0
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 166;
	
	  ;% rtP.FromWs_Data0
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 172;
	
	  ;% rtP.rpm_Gain
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 178;
	
	  ;% rtP.Constant3_Value
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 179;
	
	  ;% rtP.Constant2_Value_h
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 180;
	
	  ;% rtP.Constant3_Value_l
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 181;
	
	  ;% rtP.Constant6_Value
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 182;
	
	  ;% rtP.Constant4_Value
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 184;
	
	  ;% rtP.ib_Gain
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 185;
	
	  ;% rtP.FromWs_Time0_n
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 186;
	
	  ;% rtP.FromWs_Data0_e
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 190;
	
	  ;% rtP.pu2radpersec_Gain
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 194;
	
	  ;% rtP.Constant_Value_a
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 195;
	
	  ;% rtP.Constant1_Value_e
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 198;
	
	  ;% rtP.LookUpTable_XData
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 199;
	
	  ;% rtP.LookUpTable_YData
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 203;
	
	  ;% rtP.RelayA_OnVal
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 207;
	
	  ;% rtP.RelayA_OffVal
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 208;
	
	  ;% rtP.RelayA_YOn
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 209;
	
	  ;% rtP.RelayA_YOff
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 210;
	
	  ;% rtP.RelayB_OnVal
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 211;
	
	  ;% rtP.RelayB_OffVal
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 212;
	
	  ;% rtP.RelayB_YOn
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 213;
	
	  ;% rtP.RelayB_YOff
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 214;
	
	  ;% rtP.RelayC_OnVal
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 215;
	
	  ;% rtP.RelayC_OffVal
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 216;
	
	  ;% rtP.RelayC_YOn
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 217;
	
	  ;% rtP.RelayC_YOff
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 218;
	
	  ;% rtP._Vb_Gain
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 219;
	
	  ;% rtP.Constant4_Value_m
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 220;
	
	  ;% rtP.Constant5_Value
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 221;
	
	  ;% rtP.Lm_nosat_Value
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 222;
	
	  ;% rtP.Switch2_Threshold
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 223;
	
	  ;% rtP.unitconversion_Gain
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 224;
	
	  ;% rtP.Constant3_Value_o
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 243;
	
	  ;% rtP.Constant4_Value_j
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 244;
	
	  ;% rtP.Constant4_Value_l
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 260;
	
	  ;% rtP.Switch1_Threshold
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 261;
	
	  ;% rtP.wbase_Gain
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 262;
	
	  ;% rtP._Tb2_Gain
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 263;
	
	  ;% rtP.F_Gain
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 264;
	
	  ;% rtP._2H_Gain
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 265;
	
	  ;% rtP.web_psb_Gain_b
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 266;
	
	  ;% rtP.integ1_IC
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 267;
	
	  ;% rtP.T_InitOutput
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 268;
	
	  ;% rtP.Integ2_IC
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 269;
	
	  ;% rtP.T1_InitOutput
	  section.data(96).logicalSrcIdx = 95;
	  section.data(96).dtTransOffset = 270;
	
	  ;% rtP.peak2rms_Gain
	  section.data(97).logicalSrcIdx = 96;
	  section.data(97).dtTransOffset = 271;
	
	  ;% rtP.donotdeletethisgain_Gain
	  section.data(98).logicalSrcIdx = 97;
	  section.data(98).dtTransOffset = 272;
	
	  ;% rtP.Gain2_Gain_i
	  section.data(99).logicalSrcIdx = 98;
	  section.data(99).dtTransOffset = 273;
	
	  ;% rtP.sinnwt_Amp
	  section.data(100).logicalSrcIdx = 99;
	  section.data(100).dtTransOffset = 274;
	
	  ;% rtP.sinnwt_Bias
	  section.data(101).logicalSrcIdx = 100;
	  section.data(101).dtTransOffset = 275;
	
	  ;% rtP.sinnwt_Phase
	  section.data(102).logicalSrcIdx = 101;
	  section.data(102).dtTransOffset = 276;
	
	  ;% rtP.cosnwt_Amp
	  section.data(103).logicalSrcIdx = 102;
	  section.data(103).dtTransOffset = 277;
	
	  ;% rtP.cosnwt_Bias
	  section.data(104).logicalSrcIdx = 103;
	  section.data(104).dtTransOffset = 278;
	
	  ;% rtP.cosnwt_Phase
	  section.data(105).logicalSrcIdx = 104;
	  section.data(105).dtTransOffset = 279;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(1) = section;
      clear section
      
      section.nData     = 9;
      section.data(9)  = dumData; %prealloc
      
	  ;% rtP.Constant_Value_cs
	  section.data(1).logicalSrcIdx = 105;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtP.Constant1_Value_m
	  section.data(2).logicalSrcIdx = 106;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtP.Constant3_Value_k
	  section.data(3).logicalSrcIdx = 107;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtP.Constant_Value_n
	  section.data(4).logicalSrcIdx = 108;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtP.Constant1_Value_om
	  section.data(5).logicalSrcIdx = 109;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtP.Constant2_Value_d
	  section.data(6).logicalSrcIdx = 110;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtP.Constant_Value_j
	  section.data(7).logicalSrcIdx = 111;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtP.Constant1_Value_ox
	  section.data(8).logicalSrcIdx = 112;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtP.Constant2_Value_e
	  section.data(9).logicalSrcIdx = 113;
	  section.data(9).dtTransOffset = 8;
	
      nTotData = nTotData + section.nData;
      paramMap.sections(2) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (parameter)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    paramMap.nTotData = nTotData;
    


  ;%**************************
  ;% Create Block Output Map *
  ;%**************************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 1;
    sectIdxOffset = 0;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc sigMap
    ;%
    sigMap.nSections           = nTotSects;
    sigMap.sectIdxOffset       = sectIdxOffset;
      sigMap.sections(nTotSects) = dumSection; %prealloc
    sigMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtB)
    ;%
      section.nData     = 95;
      section.data(95)  = dumData; %prealloc
      
	  ;% rtB.Rotorspeedwm
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtB.Integrator
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtB.Linv
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 5;
	
	  ;% rtB.Product3
	  section.data(4).logicalSrcIdx = 3;
	  section.data(4).dtTransOffset = 21;
	
	  ;% rtB.iqsids
	  section.data(5).logicalSrcIdx = 4;
	  section.data(5).dtTransOffset = 25;
	
	  ;% rtB.Mult1
	  section.data(6).logicalSrcIdx = 5;
	  section.data(6).dtTransOffset = 27;
	
	  ;% rtB.Sum2
	  section.data(7).logicalSrcIdx = 6;
	  section.data(7).dtTransOffset = 29;
	
	  ;% rtB.Rotoranglethetam
	  section.data(8).logicalSrcIdx = 7;
	  section.data(8).dtTransOffset = 30;
	
	  ;% rtB.MultiportSwitch
	  section.data(9).logicalSrcIdx = 8;
	  section.data(9).dtTransOffset = 31;
	
	  ;% rtB.MultiportSwitch_k
	  section.data(10).logicalSrcIdx = 9;
	  section.data(10).dtTransOffset = 35;
	
	  ;% rtB.MultiportSwitch1
	  section.data(11).logicalSrcIdx = 10;
	  section.data(11).dtTransOffset = 37;
	
	  ;% rtB.ib
	  section.data(12).logicalSrcIdx = 11;
	  section.data(12).dtTransOffset = 39;
	
	  ;% rtB.Sum7
	  section.data(13).logicalSrcIdx = 12;
	  section.data(13).dtTransOffset = 43;
	
	  ;% rtB.Sum4
	  section.data(14).logicalSrcIdx = 13;
	  section.data(14).dtTransOffset = 46;
	
	  ;% rtB.Sum5
	  section.data(15).logicalSrcIdx = 14;
	  section.data(15).dtTransOffset = 47;
	
	  ;% rtB.StateSpace
	  section.data(16).logicalSrcIdx = 15;
	  section.data(16).dtTransOffset = 48;
	
	  ;% rtB._Vb
	  section.data(17).logicalSrcIdx = 16;
	  section.data(17).dtTransOffset = 51;
	
	  ;% rtB.MultiportSwitch_c
	  section.data(18).logicalSrcIdx = 17;
	  section.data(18).dtTransOffset = 55;
	
	  ;% rtB.MultiportSwitch1_p
	  section.data(19).logicalSrcIdx = 18;
	  section.data(19).dtTransOffset = 57;
	
	  ;% rtB.MultiportSwitch1_i
	  section.data(20).logicalSrcIdx = 19;
	  section.data(20).dtTransOffset = 59;
	
	  ;% rtB.RLinv
	  section.data(21).logicalSrcIdx = 20;
	  section.data(21).dtTransOffset = 75;
	
	  ;% rtB.A
	  section.data(22).logicalSrcIdx = 21;
	  section.data(22).dtTransOffset = 91;
	
	  ;% rtB.Product1
	  section.data(23).logicalSrcIdx = 22;
	  section.data(23).dtTransOffset = 107;
	
	  ;% rtB.sum1
	  section.data(24).logicalSrcIdx = 23;
	  section.data(24).dtTransOffset = 111;
	
	  ;% rtB.wbase
	  section.data(25).logicalSrcIdx = 24;
	  section.data(25).dtTransOffset = 115;
	
	  ;% rtB._Tb2
	  section.data(26).logicalSrcIdx = 25;
	  section.data(26).dtTransOffset = 119;
	
	  ;% rtB.F
	  section.data(27).logicalSrcIdx = 26;
	  section.data(27).dtTransOffset = 120;
	
	  ;% rtB.Sum
	  section.data(28).logicalSrcIdx = 27;
	  section.data(28).dtTransOffset = 121;
	
	  ;% rtB._2H
	  section.data(29).logicalSrcIdx = 28;
	  section.data(29).dtTransOffset = 122;
	
	  ;% rtB.web_psb
	  section.data(30).logicalSrcIdx = 29;
	  section.data(30).dtTransOffset = 123;
	
	  ;% rtB.integ1
	  section.data(31).logicalSrcIdx = 30;
	  section.data(31).dtTransOffset = 124;
	
	  ;% rtB.Integ2
	  section.data(32).logicalSrcIdx = 31;
	  section.data(32).dtTransOffset = 125;
	
	  ;% rtB.donotdeletethisgain
	  section.data(33).logicalSrcIdx = 32;
	  section.data(33).dtTransOffset = 126;
	
	  ;% rtB.Gain1
	  section.data(34).logicalSrcIdx = 33;
	  section.data(34).dtTransOffset = 127;
	
	  ;% rtB.Product
	  section.data(35).logicalSrcIdx = 34;
	  section.data(35).dtTransOffset = 128;
	
	  ;% rtB.Product1_i
	  section.data(36).logicalSrcIdx = 35;
	  section.data(36).dtTransOffset = 129;
	
	  ;% rtB.Constant
	  section.data(37).logicalSrcIdx = 36;
	  section.data(37).dtTransOffset = 130;
	
	  ;% rtB.Gain3
	  section.data(38).logicalSrcIdx = 37;
	  section.data(38).dtTransOffset = 132;
	
	  ;% rtB.TrigonometricFunction
	  section.data(39).logicalSrcIdx = 38;
	  section.data(39).dtTransOffset = 133;
	
	  ;% rtB.TrigonometricFunction1
	  section.data(40).logicalSrcIdx = 39;
	  section.data(40).dtTransOffset = 134;
	
	  ;% rtB.W43wr
	  section.data(41).logicalSrcIdx = 40;
	  section.data(41).dtTransOffset = 135;
	
	  ;% rtB.Constant_c
	  section.data(42).logicalSrcIdx = 41;
	  section.data(42).dtTransOffset = 151;
	
	  ;% rtB.Gain1_i
	  section.data(43).logicalSrcIdx = 42;
	  section.data(43).dtTransOffset = 153;
	
	  ;% rtB.TrigonometricFunction_i
	  section.data(44).logicalSrcIdx = 43;
	  section.data(44).dtTransOffset = 154;
	
	  ;% rtB.TrigonometricFunction1_c
	  section.data(45).logicalSrcIdx = 44;
	  section.data(45).dtTransOffset = 155;
	
	  ;% rtB.W21wr
	  section.data(46).logicalSrcIdx = 45;
	  section.data(46).dtTransOffset = 156;
	
	  ;% rtB.wewr
	  section.data(47).logicalSrcIdx = 46;
	  section.data(47).dtTransOffset = 172;
	
	  ;% rtB.Gain2
	  section.data(48).logicalSrcIdx = 47;
	  section.data(48).dtTransOffset = 173;
	
	  ;% rtB.th
	  section.data(49).logicalSrcIdx = 48;
	  section.data(49).dtTransOffset = 174;
	
	  ;% rtB.beta
	  section.data(50).logicalSrcIdx = 49;
	  section.data(50).dtTransOffset = 175;
	
	  ;% rtB.TrigonometricFunction_b
	  section.data(51).logicalSrcIdx = 50;
	  section.data(51).dtTransOffset = 176;
	
	  ;% rtB.TrigonometricFunction1_m
	  section.data(52).logicalSrcIdx = 51;
	  section.data(52).dtTransOffset = 177;
	
	  ;% rtB.TrigonometricFunction2
	  section.data(53).logicalSrcIdx = 52;
	  section.data(53).dtTransOffset = 178;
	
	  ;% rtB.TrigonometricFunction3
	  section.data(54).logicalSrcIdx = 53;
	  section.data(54).dtTransOffset = 179;
	
	  ;% rtB.W43wr1
	  section.data(55).logicalSrcIdx = 54;
	  section.data(55).dtTransOffset = 180;
	
	  ;% rtB.ira
	  section.data(56).logicalSrcIdx = 55;
	  section.data(56).dtTransOffset = 196;
	
	  ;% rtB.irb
	  section.data(57).logicalSrcIdx = 56;
	  section.data(57).dtTransOffset = 197;
	
	  ;% rtB.isa
	  section.data(58).logicalSrcIdx = 57;
	  section.data(58).dtTransOffset = 198;
	
	  ;% rtB.isb
	  section.data(59).logicalSrcIdx = 58;
	  section.data(59).dtTransOffset = 199;
	
	  ;% rtB.ira_c
	  section.data(60).logicalSrcIdx = 59;
	  section.data(60).dtTransOffset = 200;
	
	  ;% rtB.irb_o
	  section.data(61).logicalSrcIdx = 60;
	  section.data(61).dtTransOffset = 201;
	
	  ;% rtB.isa_m
	  section.data(62).logicalSrcIdx = 61;
	  section.data(62).dtTransOffset = 202;
	
	  ;% rtB.isb_h
	  section.data(63).logicalSrcIdx = 62;
	  section.data(63).dtTransOffset = 203;
	
	  ;% rtB.ira_d
	  section.data(64).logicalSrcIdx = 63;
	  section.data(64).dtTransOffset = 204;
	
	  ;% rtB.irb_c
	  section.data(65).logicalSrcIdx = 64;
	  section.data(65).dtTransOffset = 205;
	
	  ;% rtB.isa_b
	  section.data(66).logicalSrcIdx = 65;
	  section.data(66).dtTransOffset = 206;
	
	  ;% rtB.isb_p
	  section.data(67).logicalSrcIdx = 66;
	  section.data(67).dtTransOffset = 207;
	
	  ;% rtB.vdr
	  section.data(68).logicalSrcIdx = 67;
	  section.data(68).dtTransOffset = 208;
	
	  ;% rtB.vds
	  section.data(69).logicalSrcIdx = 68;
	  section.data(69).dtTransOffset = 209;
	
	  ;% rtB.vqr
	  section.data(70).logicalSrcIdx = 69;
	  section.data(70).dtTransOffset = 210;
	
	  ;% rtB.vqs
	  section.data(71).logicalSrcIdx = 70;
	  section.data(71).dtTransOffset = 211;
	
	  ;% rtB.vdr_e
	  section.data(72).logicalSrcIdx = 71;
	  section.data(72).dtTransOffset = 212;
	
	  ;% rtB.vds_o
	  section.data(73).logicalSrcIdx = 72;
	  section.data(73).dtTransOffset = 213;
	
	  ;% rtB.vqr_j
	  section.data(74).logicalSrcIdx = 73;
	  section.data(74).dtTransOffset = 214;
	
	  ;% rtB.vqs_m
	  section.data(75).logicalSrcIdx = 74;
	  section.data(75).dtTransOffset = 215;
	
	  ;% rtB.vdr_ex
	  section.data(76).logicalSrcIdx = 75;
	  section.data(76).dtTransOffset = 216;
	
	  ;% rtB.vds_p
	  section.data(77).logicalSrcIdx = 76;
	  section.data(77).dtTransOffset = 217;
	
	  ;% rtB.vqr_b
	  section.data(78).logicalSrcIdx = 77;
	  section.data(78).dtTransOffset = 218;
	
	  ;% rtB.vqs_mg
	  section.data(79).logicalSrcIdx = 78;
	  section.data(79).dtTransOffset = 219;
	
	  ;% rtB.Integrator_g
	  section.data(80).logicalSrcIdx = 79;
	  section.data(80).dtTransOffset = 220;
	
	  ;% rtB.TmpSignalConversionAtMathFuncti
	  section.data(81).logicalSrcIdx = 80;
	  section.data(81).dtTransOffset = 221;
	
	  ;% rtB.Sum2_f
	  section.data(82).logicalSrcIdx = 81;
	  section.data(82).dtTransOffset = 224;
	
	  ;% rtB.Product2
	  section.data(83).logicalSrcIdx = 82;
	  section.data(83).dtTransOffset = 225;
	
	  ;% rtB.Product_a
	  section.data(84).logicalSrcIdx = 83;
	  section.data(84).dtTransOffset = 227;
	
	  ;% rtB.phimq
	  section.data(85).logicalSrcIdx = 84;
	  section.data(85).dtTransOffset = 229;
	
	  ;% rtB.Product1_ia
	  section.data(86).logicalSrcIdx = 85;
	  section.data(86).dtTransOffset = 230;
	
	  ;% rtB.phimd
	  section.data(87).logicalSrcIdx = 86;
	  section.data(87).dtTransOffset = 232;
	
	  ;% rtB.Isat
	  section.data(88).logicalSrcIdx = 87;
	  section.data(88).dtTransOffset = 233;
	
	  ;% rtB.Lm
	  section.data(89).logicalSrcIdx = 88;
	  section.data(89).dtTransOffset = 234;
	
	  ;% rtB.Sum2_c
	  section.data(90).logicalSrcIdx = 89;
	  section.data(90).dtTransOffset = 235;
	
	  ;% rtB.Linv_m
	  section.data(91).logicalSrcIdx = 90;
	  section.data(91).dtTransOffset = 251;
	
	  ;% rtB.RLinv_p
	  section.data(92).logicalSrcIdx = 91;
	  section.data(92).dtTransOffset = 267;
	
	  ;% rtB.Add
	  section.data(93).logicalSrcIdx = 92;
	  section.data(93).dtTransOffset = 283;
	
	  ;% rtB.TT1e6s
	  section.data(94).logicalSrcIdx = 93;
	  section.data(94).dtTransOffset = 284;
	
	  ;% rtB.Lm_e
	  section.data(95).logicalSrcIdx = 94;
	  section.data(95).dtTransOffset = 285;
	
      nTotData = nTotData + section.nData;
      sigMap.sections(1) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (signal)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    sigMap.nTotData = nTotData;
    


  ;%*******************
  ;% Create DWork Map *
  ;%*******************
      
    nTotData      = 0; %add to this count as we go
    nTotSects     = 5;
    sectIdxOffset = 1;
    
    ;%
    ;% Define dummy sections & preallocate arrays
    ;%
    dumSection.nData = -1;  
    dumSection.data  = [];
    
    dumData.logicalSrcIdx = -1;
    dumData.dtTransOffset = -1;
    
    ;%
    ;% Init/prealloc dworkMap
    ;%
    dworkMap.nSections           = nTotSects;
    dworkMap.sectIdxOffset       = sectIdxOffset;
      dworkMap.sections(nTotSects) = dumSection; %prealloc
    dworkMap.nTotData            = -1;
    
    ;%
    ;% Auto data (rtDW)
    ;%
      section.nData     = 3;
      section.data(3)  = dumData; %prealloc
      
	  ;% rtDW.inversion_DWORK4
	  section.data(1).logicalSrcIdx = 0;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.T_RWORK.modelTStart
	  section.data(2).logicalSrcIdx = 1;
	  section.data(2).dtTransOffset = 16;
	
	  ;% rtDW.T1_RWORK.modelTStart
	  section.data(3).logicalSrcIdx = 2;
	  section.data(3).dtTransOffset = 17;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(1) = section;
      clear section
      
      section.nData     = 9;
      section.data(9)  = dumData; %prealloc
      
	  ;% rtDW.FromWs_PWORK.TimePtr
	  section.data(1).logicalSrcIdx = 3;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.TeNmNrpm_PWORK.LoggedData
	  section.data(2).logicalSrcIdx = 4;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.FromWs_PWORK_b.TimePtr
	  section.data(3).logicalSrcIdx = 5;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.StateSpace_PWORK.AS
	  section.data(4).logicalSrcIdx = 6;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.irisA_PWORK.LoggedData
	  section.data(5).logicalSrcIdx = 7;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.V_trian_PWORK.LoggedData
	  section.data(6).logicalSrcIdx = 8;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.T_PWORK.TUbufferPtrs
	  section.data(7).logicalSrcIdx = 9;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtDW.T1_PWORK.TUbufferPtrs
	  section.data(8).logicalSrcIdx = 10;
	  section.data(8).dtTransOffset = 8;
	
	  ;% rtDW.V_ab_PWORK.LoggedData
	  section.data(9).logicalSrcIdx = 11;
	  section.data(9).dtTransOffset = 10;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(2) = section;
      clear section
      
      section.nData     = 9;
      section.data(9)  = dumData; %prealloc
      
	  ;% rtDW.FromWs_ZCTimeIndices
	  section.data(1).logicalSrcIdx = 12;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.FromWs_CurZCTimeIndIdx
	  section.data(2).logicalSrcIdx = 13;
	  section.data(2).dtTransOffset = 2;
	
	  ;% rtDW.FromWs_IWORK.PrevIndex
	  section.data(3).logicalSrcIdx = 14;
	  section.data(3).dtTransOffset = 3;
	
	  ;% rtDW.FromWs_ZCTimeIndices_c
	  section.data(4).logicalSrcIdx = 15;
	  section.data(4).dtTransOffset = 4;
	
	  ;% rtDW.FromWs_CurZCTimeIndIdx_f
	  section.data(5).logicalSrcIdx = 16;
	  section.data(5).dtTransOffset = 5;
	
	  ;% rtDW.FromWs_IWORK_p.PrevIndex
	  section.data(6).logicalSrcIdx = 17;
	  section.data(6).dtTransOffset = 6;
	
	  ;% rtDW.StateSpace_IWORK
	  section.data(7).logicalSrcIdx = 18;
	  section.data(7).dtTransOffset = 7;
	
	  ;% rtDW.T_IWORK.Tail
	  section.data(8).logicalSrcIdx = 19;
	  section.data(8).dtTransOffset = 11;
	
	  ;% rtDW.T1_IWORK.Tail
	  section.data(9).logicalSrcIdx = 20;
	  section.data(9).dtTransOffset = 12;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(3) = section;
      clear section
      
      section.nData     = 1;
      section.data(1)  = dumData; %prealloc
      
	  ;% rtDW.Sqrt_DWORK1
	  section.data(1).logicalSrcIdx = 21;
	  section.data(1).dtTransOffset = 0;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(4) = section;
      clear section
      
      section.nData     = 14;
      section.data(14)  = dumData; %prealloc
      
	  ;% rtDW.RelayA_Mode
	  section.data(1).logicalSrcIdx = 22;
	  section.data(1).dtTransOffset = 0;
	
	  ;% rtDW.RelayB_Mode
	  section.data(2).logicalSrcIdx = 23;
	  section.data(2).dtTransOffset = 1;
	
	  ;% rtDW.RelayC_Mode
	  section.data(3).logicalSrcIdx = 24;
	  section.data(3).dtTransOffset = 2;
	
	  ;% rtDW.Switch_Mode
	  section.data(4).logicalSrcIdx = 25;
	  section.data(4).dtTransOffset = 3;
	
	  ;% rtDW.Saturation_MODE
	  section.data(5).logicalSrcIdx = 26;
	  section.data(5).dtTransOffset = 4;
	
	  ;% rtDW.sinthrcosthr_MODE
	  section.data(6).logicalSrcIdx = 27;
	  section.data(6).dtTransOffset = 5;
	
	  ;% rtDW.sinthrcosthr1_MODE
	  section.data(7).logicalSrcIdx = 28;
	  section.data(7).dtTransOffset = 6;
	
	  ;% rtDW.sinbetacosbetasinthcosth_MODE
	  section.data(8).logicalSrcIdx = 29;
	  section.data(8).dtTransOffset = 7;
	
	  ;% rtDW.Rotorreferenceframe_MODE
	  section.data(9).logicalSrcIdx = 30;
	  section.data(9).dtTransOffset = 8;
	
	  ;% rtDW.Stationaryreferenceframe_MODE
	  section.data(10).logicalSrcIdx = 31;
	  section.data(10).dtTransOffset = 9;
	
	  ;% rtDW.Synchronousreferenceframe_MODE
	  section.data(11).logicalSrcIdx = 32;
	  section.data(11).dtTransOffset = 10;
	
	  ;% rtDW.Rotorreferenceframe_MODE_g
	  section.data(12).logicalSrcIdx = 33;
	  section.data(12).dtTransOffset = 11;
	
	  ;% rtDW.Stationaryreferenceframe_MODE_a
	  section.data(13).logicalSrcIdx = 34;
	  section.data(13).dtTransOffset = 12;
	
	  ;% rtDW.Synchronousreferenceframe_MOD_l
	  section.data(14).logicalSrcIdx = 35;
	  section.data(14).dtTransOffset = 13;
	
      nTotData = nTotData + section.nData;
      dworkMap.sections(5) = section;
      clear section
      
    
      ;%
      ;% Non-auto Data (dwork)
      ;%
    

    ;%
    ;% Add final counts to struct.
    ;%
    dworkMap.nTotData = nTotData;
    


  ;%
  ;% Add individual maps to base struct.
  ;%

  targMap.paramMap  = paramMap;    
  targMap.signalMap = sigMap;
  targMap.dworkMap  = dworkMap;
  
  ;%
  ;% Add checksums to base struct.
  ;%


  targMap.checksum0 = 3736795049;
  targMap.checksum1 = 3895000086;
  targMap.checksum2 = 2409864627;
  targMap.checksum3 = 1052769672;

