/*
 * induction_motor_drive.h
 *
 * Code generation for model "induction_motor_drive".
 *
 * Model version              : 1.147
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Sat Feb 13 22:10:01 2016
 *
 * Target selection: rsim.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#ifndef RTW_HEADER_induction_motor_drive_h_
#define RTW_HEADER_induction_motor_drive_h_
#include <math.h>
#include <stddef.h>
#include <float.h>
#include <string.h>
#ifndef induction_motor_drive_COMMON_INCLUDES_
# define induction_motor_drive_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rsim.h"
#include "rt_logging.h"
#include "dt_info.h"
#endif                                 /* induction_motor_drive_COMMON_INCLUDES_ */

#include "induction_motor_drive_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_defines.h"
#include "rt_look.h"
#include "rt_look1d.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"
#define MODEL_NAME                     induction_motor_drive
#define NSAMPLE_TIMES                  (2)                       /* Number of sample times */
#define NINPUTS                        (0)                       /* Number of model inputs */
#define NOUTPUTS                       (0)                       /* Number of model outputs */
#define NBLOCKIO                       (95)                      /* Number of data output port signals */
#define NUM_ZC_EVENTS                  (0)                       /* Number of zero-crossing events */
#ifndef NCSTATES
# define NCSTATES                      (9)                       /* Number of continuous states */
#elif NCSTATES != 9
# error Invalid specification of NCSTATES defined in compiler command
#endif

#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        (NULL)
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T Rotorspeedwm;                 /* '<S35>/Rotor speed (wm)' */
  real_T Integrator[4];                /* '<S19>/Integrator' */
  real_T Linv[16];                     /* '<S13>/Switch' */
  real_T Product3[4];                  /* '<S13>/Product3' */
  real_T iqsids[2];                    /* '<S17>/1-1' */
  real_T Mult1[2];                     /* '<S17>/Mult1' */
  real_T Sum2;                         /* '<S17>/Sum2' */
  real_T Rotoranglethetam;             /* '<S35>/Rotor angle thetam' */
  real_T MultiportSwitch[4];           /* '<S16>/Multiport Switch' */
  real_T MultiportSwitch_k[2];         /* '<S15>/Multiport Switch' */
  real_T MultiportSwitch1[2];          /* '<S15>/Multiport Switch1' */
  real_T ib[4];                        /* '<S15>/ib' */
  real_T Sum7[3];                      /* '<Root>/Sum7' */
  real_T Sum4;                         /* '<Root>/Sum4' */
  real_T Sum5;                         /* '<Root>/Sum5' */
  real_T StateSpace[3];                /* '<S36>/State-Space' */
  real_T _Vb[4];                       /* '<S14>/1_Vb' */
  real_T MultiportSwitch_c[2];         /* '<S14>/Multiport Switch' */
  real_T MultiportSwitch1_p[2];        /* '<S14>/Multiport Switch1' */
  real_T MultiportSwitch1_i[16];       /* '<S16>/Multiport Switch1' */
  real_T RLinv[16];                    /* '<S13>/Switch1' */
  real_T A[16];                        /* '<S13>/Sum1' */
  real_T Product1[4];                  /* '<S19>/Product1' */
  real_T sum1[4];                      /* '<S19>/sum1' */
  real_T wbase[4];                     /* '<S19>/wbase' */
  real_T _Tb2;                         /* '<S35>/1_Tb2' */
  real_T F;                            /* '<S35>/F' */
  real_T Sum;                          /* '<S35>/Sum' */
  real_T _2H;                          /* '<S35>/1_2H' */
  real_T web_psb;                      /* '<S35>/web_psb' */
  real_T integ1;                       /* '<S2>/integ1' */
  real_T Integ2;                       /* '<S2>/Integ2' */
  real_T donotdeletethisgain;          /* '<S7>/do not delete this gain' */
  real_T Gain1;                        /* '<S2>/Gain1' */
  real_T Product;                      /* '<S2>/Product' */
  real_T Product1_i;                   /* '<S2>/Product1' */
  real_T Constant[2];                  /* '<S33>/Constant' */
  real_T Gain3;                        /* '<S33>/Gain3' */
  real_T TrigonometricFunction;        /* '<S33>/Trigonometric Function' */
  real_T TrigonometricFunction1;       /* '<S33>/Trigonometric Function1' */
  real_T W43wr[16];                    /* '<S33>/W(4,3)=wr' */
  real_T Constant_c[2];                /* '<S32>/Constant' */
  real_T Gain1_i;                      /* '<S32>/Gain1' */
  real_T TrigonometricFunction_i;      /* '<S32>/Trigonometric Function' */
  real_T TrigonometricFunction1_c;     /* '<S32>/Trigonometric Function1' */
  real_T W21wr[16];                    /* '<S32>/W(2,1)=-wr' */
  real_T wewr;                         /* '<S31>/Sum' */
  real_T Gain2;                        /* '<S31>/Gain2' */
  real_T th;                           /* '<S31>/web_psb' */
  real_T beta;                         /* '<S31>/Sum1' */
  real_T TrigonometricFunction_b;      /* '<S31>/Trigonometric Function' */
  real_T TrigonometricFunction1_m;     /* '<S31>/Trigonometric Function1' */
  real_T TrigonometricFunction2;       /* '<S31>/Trigonometric Function2' */
  real_T TrigonometricFunction3;       /* '<S31>/Trigonometric Function3' */
  real_T W43wr1[16];                   /* '<S31>/W(4,3)=wr-1' */
  real_T ira;                          /* '<S30>/ira' */
  real_T irb;                          /* '<S30>/irb' */
  real_T isa;                          /* '<S30>/isa' */
  real_T isb;                          /* '<S30>/isb' */
  real_T ira_c;                        /* '<S29>/ira' */
  real_T irb_o;                        /* '<S29>/irb' */
  real_T isa_m;                        /* '<S29>/isa' */
  real_T isb_h;                        /* '<S29>/isb' */
  real_T ira_d;                        /* '<S28>/ira' */
  real_T irb_c;                        /* '<S28>/irb' */
  real_T isa_b;                        /* '<S28>/isa' */
  real_T isb_p;                        /* '<S28>/isb' */
  real_T vdr;                          /* '<S26>/vdr' */
  real_T vds;                          /* '<S26>/vds' */
  real_T vqr;                          /* '<S26>/vqr' */
  real_T vqs;                          /* '<S26>/vqs' */
  real_T vdr_e;                        /* '<S25>/vdr' */
  real_T vds_o;                        /* '<S25>/vds' */
  real_T vqr_j;                        /* '<S25>/vqr' */
  real_T vqs_m;                        /* '<S25>/vqs' */
  real_T vdr_ex;                       /* '<S24>/vdr' */
  real_T vds_p;                        /* '<S24>/vds' */
  real_T vqr_b;                        /* '<S24>/vqr' */
  real_T vqs_mg;                       /* '<S24>/vqs' */
  real_T Integrator_g;                 /* '<S22>/Integrator' */
  real_T TmpSignalConversionAtMathFuncti[3];
  real_T Sum2_f;                       /* '<S20>/Sum2' */
  real_T Product2[2];                  /* '<S23>/Product2' */
  real_T Product_a[2];                 /* '<S23>/Product' */
  real_T phimq;                        /* '<S23>/Sum2' */
  real_T Product1_ia[2];               /* '<S23>/Product1' */
  real_T phimd;                        /* '<S23>/Sum1' */
  real_T Isat;                         /* '<S18>/Lookup Table' */
  real_T Lm;                           /* '<S18>/Switch' */
  real_T Sum2_c[16];                   /* '<S21>/Sum2' */
  real_T Linv_m[16];                   /* '<S18>/inversion' */
  real_T RLinv_p[16];                  /* '<S18>/Product1' */
  real_T Add;                          /* '<S22>/Add' */
  real_T TT1e6s;                       /* '<S22>/1//T (T= 1e-6s)' */
  real_T Lm_e;                         /* '<S18>/Product' */
} B;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  real_T inversion_DWORK4[16];         /* '<S18>/inversion' */
  struct {
    real_T modelTStart;
  } T_RWORK;                           /* '<S2>/T' */

  struct {
    real_T modelTStart;
  } T1_RWORK;                          /* '<S2>/T1' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK;                      /* '<S3>/FromWs' */

  struct {
    void *LoggedData;
  } TeNmNrpm_PWORK;                    /* '<Root>/Te (N.m), N(rpm)' */

  struct {
    void *TimePtr;
    void *DataPtr;
    void *RSimInfoPtr;
  } FromWs_PWORK_b;                    /* '<S8>/FromWs' */

  struct {
    void *AS;
    void *BS;
    void *CS;
    void *DS;
    void *DX_COL;
    void *BD_COL;
    void *TMP1;
    void *TMP2;
    void *SWITCH_STATUS;
    void *SWITCH_STATUS_INIT;
    void *SW_CHG;
    void *CHOPPER;
    void *G_STATE;
    void *IDX_SW_CHG;
    void *Y_SWITCH;
    void *SWITCH_TYPES;
    void *IDX_OUT_SW;
  } StateSpace_PWORK;                  /* '<S36>/State-Space' */

  struct {
    void *LoggedData;
  } irisA_PWORK;                       /* '<Root>/ir,is (A)' */

  struct {
    void *LoggedData;
  } V_trian_PWORK;                     /* '<Root>/V_trian' */

  struct {
    void *TUbufferPtrs[2];
  } T_PWORK;                           /* '<S2>/T' */

  struct {
    void *TUbufferPtrs[2];
  } T1_PWORK;                          /* '<S2>/T1' */

  struct {
    void *LoggedData;
  } V_ab_PWORK;                        /* '<Root>/V_ab' */

  int_T FromWs_ZCTimeIndices[2];       /* '<S3>/FromWs' */
  int_T FromWs_CurZCTimeIndIdx;        /* '<S3>/FromWs' */
  struct {
    int_T PrevIndex;
  } FromWs_IWORK;                      /* '<S3>/FromWs' */

  int_T FromWs_ZCTimeIndices_c;        /* '<S8>/FromWs' */
  int_T FromWs_CurZCTimeIndIdx_f;      /* '<S8>/FromWs' */
  struct {
    int_T PrevIndex;
  } FromWs_IWORK_p;                    /* '<S8>/FromWs' */

  int_T StateSpace_IWORK[4];           /* '<S36>/State-Space' */
  struct {
    int_T Tail;
    int_T Head;
    int_T Last;
    int_T CircularBufSize;
    int_T MaxNewBufSize;
  } T_IWORK;                           /* '<S2>/T' */

  struct {
    int_T Tail;
    int_T Head;
    int_T Last;
    int_T CircularBufSize;
    int_T MaxNewBufSize;
  } T1_IWORK;                          /* '<S2>/T1' */

  int8_T Sqrt_DWORK1;                  /* '<S2>/Sqrt' */
  boolean_T RelayA_Mode;               /* '<Root>/RelayA' */
  boolean_T RelayB_Mode;               /* '<Root>/RelayB' */
  boolean_T RelayC_Mode;               /* '<Root>/RelayC' */
  boolean_T Switch_Mode;               /* '<S18>/Switch' */
  boolean_T Saturation_MODE;           /* '<S13>/Saturation' */
  boolean_T sinthrcosthr_MODE;         /* '<S16>/sin(thr),cos(thr)' */
  boolean_T sinthrcosthr1_MODE;        /* '<S16>/sin(thr),cos(thr)1' */
  boolean_T sinbetacosbetasinthcosth_MODE;/* '<S16>/sin(beta),cos(beta),sin(th),cos(th)' */
  boolean_T Rotorreferenceframe_MODE;  /* '<S15>/Rotor reference frame' */
  boolean_T Stationaryreferenceframe_MODE;/* '<S15>/Stationary reference frame' */
  boolean_T Synchronousreferenceframe_MODE;/* '<S15>/Synchronous reference frame' */
  boolean_T Rotorreferenceframe_MODE_g;/* '<S14>/Rotor reference frame' */
  boolean_T Stationaryreferenceframe_MODE_a;/* '<S14>/Stationary reference frame' */
  boolean_T Synchronousreferenceframe_MOD_l;/* '<S14>/Synchronous reference frame' */
} DW;

/* Continuous states (auto storage) */
typedef struct {
  real_T Rotorspeedwm_CSTATE;          /* '<S35>/Rotor speed (wm)' */
  real_T Integrator_CSTATE[4];         /* '<S19>/Integrator' */
  real_T Rotoranglethetam_CSTATE;      /* '<S35>/Rotor angle thetam' */
  real_T integ1_CSTATE;                /* '<S2>/integ1' */
  real_T Integ2_CSTATE;                /* '<S2>/Integ2' */
  real_T Integrator_CSTATE_k;          /* '<S22>/Integrator' */
} X;

/* State derivatives (auto storage) */
typedef struct {
  real_T Rotorspeedwm_CSTATE;          /* '<S35>/Rotor speed (wm)' */
  real_T Integrator_CSTATE[4];         /* '<S19>/Integrator' */
  real_T Rotoranglethetam_CSTATE;      /* '<S35>/Rotor angle thetam' */
  real_T integ1_CSTATE;                /* '<S2>/integ1' */
  real_T Integ2_CSTATE;                /* '<S2>/Integ2' */
  real_T Integrator_CSTATE_k;          /* '<S22>/Integrator' */
} XDot;

/* State disabled  */
typedef struct {
  boolean_T Rotorspeedwm_CSTATE;       /* '<S35>/Rotor speed (wm)' */
  boolean_T Integrator_CSTATE[4];      /* '<S19>/Integrator' */
  boolean_T Rotoranglethetam_CSTATE;   /* '<S35>/Rotor angle thetam' */
  boolean_T integ1_CSTATE;             /* '<S2>/integ1' */
  boolean_T Integ2_CSTATE;             /* '<S2>/Integ2' */
  boolean_T Integrator_CSTATE_k;       /* '<S22>/Integrator' */
} XDis;

/* Continuous State Absolute Tolerance  */
typedef struct {
  real_T Rotorspeedwm_CSTATE;          /* '<S35>/Rotor speed (wm)' */
  real_T Integrator_CSTATE[4];         /* '<S19>/Integrator' */
  real_T Rotoranglethetam_CSTATE;      /* '<S35>/Rotor angle thetam' */
  real_T integ1_CSTATE;                /* '<S2>/integ1' */
  real_T Integ2_CSTATE;                /* '<S2>/Integ2' */
  real_T Integrator_CSTATE_k;          /* '<S22>/Integrator' */
} CStateAbsTol;

/* Zero-crossing (trigger) state */
typedef struct {
  real_T FromWs_repeatedTime_ZC;       /* '<S3>/FromWs' */
  real_T FromWs_repeatedTime_ZC_h;     /* '<S8>/FromWs' */
  real_T RelayA_RelayZC_ZC;            /* '<Root>/RelayA' */
  real_T RelayB_RelayZC_ZC;            /* '<Root>/RelayB' */
  real_T RelayC_RelayZC_ZC;            /* '<Root>/RelayC' */
  real_T Switch_SwitchCond_ZC;         /* '<S18>/Switch' */
} ZCV;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState FromWs_repeatedTime_ZCE;  /* '<S3>/FromWs' */
  ZCSigState FromWs_repeatedTime_ZCE_c;/* '<S8>/FromWs' */
  ZCSigState RelayA_RelayZC_ZCE;       /* '<Root>/RelayA' */
  ZCSigState RelayB_RelayZC_ZCE;       /* '<Root>/RelayB' */
  ZCSigState RelayC_RelayZC_ZCE;       /* '<Root>/RelayC' */
  ZCSigState Switch_SwitchCond_ZCE;    /* '<S18>/Switch' */
} PrevZCX;

/* Parameters (auto storage) */
struct P_ {
  real_T Fourier_f1;                   /* Mask Parameter: Fourier_f1
                                        * Referenced by:
                                        *   '<S2>/Gain1'
                                        *   '<S2>/cos(nwt)'
                                        *   '<S2>/sin(nwt)'
                                        *   '<S2>/T'
                                        *   '<S2>/T1'
                                        */
  real_T Fourier_n;                    /* Mask Parameter: Fourier_n
                                        * Referenced by:
                                        *   '<S2>/cos(nwt)'
                                        *   '<S2>/sin(nwt)'
                                        */
  real_T Constant1_Value;              /* Expression: SM.Lsat(1)
                                        * Referenced by: '<S18>/Constant1'
                                        */
  real_T u2_Value[2];                  /* Expression: [ SM.Lls SM.Llr ]
                                        * Referenced by: '<S20>/u2'
                                        */
  real_T Integrator_IC;                /* Expression: SM.Lsat(1)
                                        * Referenced by: '<S22>/Integrator'
                                        */
  real_T u1_Value[2];                  /* Expression: [1/SM.Lls 1/SM.Llr]
                                        * Referenced by: '<S23>/u1'
                                        */
  real_T LookupTable_XData[2];         /* Expression: SM.Phisat
                                        * Referenced by: '<S18>/Lookup Table'
                                        */
  real_T LookupTable_YData[2];         /* Expression: [ 0 SM.Phisat(2:end)./SM.Lsat(2:end) ]
                                        * Referenced by: '<S18>/Lookup Table'
                                        */
  real_T u1_Value_b[16];               /* Expression: zeros(4,4)
                                        * Referenced by: '<S21>/u1'
                                        */
  real_T u5_Value[16];                 /* Expression: SM.Ll
                                        * Referenced by: '<S21>/u5'
                                        */
  real_T u1_Value_f[16];               /* Expression: SM.R
                                        * Referenced by: '<S18>/u1'
                                        */
  real_T TT1e6s_Gain;                  /* Expression: 1/1e-6
                                        * Referenced by: '<S22>/1//T (T= 1e-6s)'
                                        */
  real_T vqrvdr_Y0;                    /* Expression: 0
                                        * Referenced by: '<S24>/vqr,vdr'
                                        */
  real_T vqsvds_Y0;                    /* Expression: 0
                                        * Referenced by: '<S24>/vqs,vds'
                                        */
  real_T vqrvdr_Y0_h;                  /* Expression: 0
                                        * Referenced by: '<S25>/vqr,vdr'
                                        */
  real_T vqsvds_Y0_g;                  /* Expression: 0
                                        * Referenced by: '<S25>/vqs,vds'
                                        */
  real_T vqrvdr_Y0_m;                  /* Expression: 0
                                        * Referenced by: '<S26>/vqr,vdr'
                                        */
  real_T vqsvds_Y0_h;                  /* Expression: 0
                                        * Referenced by: '<S26>/vqs,vds'
                                        */
  real_T irairb_Y0;                    /* Expression: 0
                                        * Referenced by: '<S28>/ira,irb'
                                        */
  real_T isaisb_Y0;                    /* Expression: 0
                                        * Referenced by: '<S28>/isa,isb'
                                        */
  real_T irairb_Y0_k;                  /* Expression: 0
                                        * Referenced by: '<S29>/ira,irb'
                                        */
  real_T isaisb_Y0_n;                  /* Expression: 0
                                        * Referenced by: '<S29>/isa,isb'
                                        */
  real_T irairb_Y0_j;                  /* Expression: 0
                                        * Referenced by: '<S30>/ira,irb'
                                        */
  real_T isaisb_Y0_c;                  /* Expression: 0
                                        * Referenced by: '<S30>/isa,isb'
                                        */
  real_T sinbetacosbetasinthcosth_Y0;  /* Expression: 0
                                        * Referenced by: '<S31>/sin(beta),cos(beta), sin(th),cos(th)'
                                        */
  real_T W_Y0;                         /* Expression: 0
                                        * Referenced by: '<S31>/W'
                                        */
  real_T we_Value;                     /* Expression: 1
                                        * Referenced by: '<S31>/we'
                                        */
  real_T Gain2_Gain;                   /* Expression: -1
                                        * Referenced by: '<S31>/Gain2'
                                        */
  real_T web_psb_Gain;                 /* Expression: SM.web
                                        * Referenced by: '<S31>/web_psb'
                                        */
  real_T u3_Value[16];                 /* Expression: [ 0 1  0  0; -1  0  0  0;  0  0  0  0;  0  0  0  0]
                                        * Referenced by: '<S31>/u3'
                                        */
  real_T sinthrcosthr_Y0;              /* Expression: 0
                                        * Referenced by: '<S32>/sin(thr),cos(thr)'
                                        */
  real_T W_Y0_d;                       /* Expression: 0
                                        * Referenced by: '<S32>/W'
                                        */
  real_T Constant_Value[2];            /* Expression: [0; 0]
                                        * Referenced by: '<S32>/Constant'
                                        */
  real_T Gain1_Gain;                   /* Expression: -1
                                        * Referenced by: '<S32>/Gain1'
                                        */
  real_T u1_Value_e[16];               /* Expression: zeros(4,4)
                                        * Referenced by: '<S32>/u1'
                                        */
  real_T sinthrcosthr_Y0_f;            /* Expression: 0
                                        * Referenced by: '<S33>/sin(thr),cos(thr)'
                                        */
  real_T Constant_Value_c[2];          /* Expression: [0; 0]
                                        * Referenced by: '<S33>/Constant'
                                        */
  real_T Gain3_Gain;                   /* Expression: -1
                                        * Referenced by: '<S33>/Gain3'
                                        */
  real_T u4_Value[16];                 /* Expression: zeros(4,4)
                                        * Referenced by: '<S33>/u4'
                                        */
  real_T Rotorspeedwm_IC;              /* Expression: SM.wmo
                                        * Referenced by: '<S35>/Rotor speed (wm)'
                                        */
  real_T Integrator_IC_o[4];           /* Expression: SM.phiqd0
                                        * Referenced by: '<S19>/Integrator'
                                        */
  real_T Constant_Value_i;             /* Expression: SM.ensat
                                        * Referenced by: '<S13>/Constant'
                                        */
  real_T Constant1_Value_o;            /* Expression: SM.ensat
                                        * Referenced by: '<S13>/Constant1'
                                        */
  real_T Constant2_Value[16];          /* Expression: SM.Linv
                                        * Referenced by: '<S13>/Constant2'
                                        */
  real_T Switch_Threshold;             /* Expression: 0.5
                                        * Referenced by: '<S13>/Switch'
                                        */
  real_T u_Gain[2];                    /* Expression: [1 -1]
                                        * Referenced by: '<S17>/1-1'
                                        */
  real_T Rotoranglethetam_IC;          /* Expression: SM.tho
                                        * Referenced by: '<S35>/Rotor angle thetam'
                                        */
  real_T p_Gain;                       /* Expression: 1/SM.p
                                        * Referenced by: '<S35>/1\p'
                                        */
  real_T Gain_Gain[3];                 /* Expression: [SM.Nb2;SM.Tb2;1]
                                        * Referenced by: '<S35>/Gain'
                                        */
  real_T FromWs_Time0[6];              /* Computed Parameter: FromWs_Time0
                                        * Referenced by: '<S3>/FromWs'
                                        */
  real_T FromWs_Data0[6];              /* Computed Parameter: FromWs_Data0
                                        * Referenced by: '<S3>/FromWs'
                                        */
  real_T rpm_Gain;                     /* Expression: 30/pi
                                        * Referenced by: '<Root>/rpm'
                                        */
  real_T Constant3_Value;              /* Expression: SM.ctrl
                                        * Referenced by: '<S15>/Constant3'
                                        */
  real_T Constant2_Value_h;            /* Expression: SM.ctrl
                                        * Referenced by: '<S16>/Constant2'
                                        */
  real_T Constant3_Value_l;            /* Expression: SM.ctrl
                                        * Referenced by: '<S14>/Constant3'
                                        */
  real_T Constant6_Value[2];           /* Expression: [0;0]
                                        * Referenced by: '<S27>/Constant6'
                                        */
  real_T Constant4_Value;              /* Expression: SM.ctrl
                                        * Referenced by: '<S15>/Constant4'
                                        */
  real_T ib_Gain;                      /* Expression: SM.ib
                                        * Referenced by: '<S15>/ib'
                                        */
  real_T FromWs_Time0_n[4];            /* Computed Parameter: FromWs_Time0_n
                                        * Referenced by: '<S8>/FromWs'
                                        */
  real_T FromWs_Data0_e[4];            /* Computed Parameter: FromWs_Data0_e
                                        * Referenced by: '<S8>/FromWs'
                                        */
  real_T pu2radpersec_Gain;            /* Expression: 2*pi*60
                                        * Referenced by: '<Root>/pu2radpersec'
                                        */
  real_T Constant_Value_a[3];          /* Expression: 2*pi/3*[ 0,-1,1 ]
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Constant1_Value_e;            /* Expression: 1/1980
                                        * Referenced by: '<Root>/Constant1'
                                        */
  real_T LookUpTable_XData[4];         /* Expression: [0 0.25  0.75  1] / 1980
                                        * Referenced by: '<Root>/Look-Up Table'
                                        */
  real_T LookUpTable_YData[4];         /* Expression: [0  1  -1  0]
                                        * Referenced by: '<Root>/Look-Up Table'
                                        */
  real_T RelayA_OnVal;                 /* Expression: 0
                                        * Referenced by: '<Root>/RelayA'
                                        */
  real_T RelayA_OffVal;                /* Expression: 0
                                        * Referenced by: '<Root>/RelayA'
                                        */
  real_T RelayA_YOn;                   /* Expression: 220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayA'
                                        */
  real_T RelayA_YOff;                  /* Expression: -220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayA'
                                        */
  real_T RelayB_OnVal;                 /* Expression: 0
                                        * Referenced by: '<Root>/RelayB'
                                        */
  real_T RelayB_OffVal;                /* Expression: 0
                                        * Referenced by: '<Root>/RelayB'
                                        */
  real_T RelayB_YOn;                   /* Expression: 220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayB'
                                        */
  real_T RelayB_YOff;                  /* Expression: -220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayB'
                                        */
  real_T RelayC_OnVal;                 /* Expression: 0
                                        * Referenced by: '<Root>/RelayC'
                                        */
  real_T RelayC_OffVal;                /* Expression: 0
                                        * Referenced by: '<Root>/RelayC'
                                        */
  real_T RelayC_YOn;                   /* Expression: 220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayC'
                                        */
  real_T RelayC_YOff;                  /* Expression: -220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayC'
                                        */
  real_T _Vb_Gain;                     /* Expression: 1/SM.Vb
                                        * Referenced by: '<S14>/1_Vb'
                                        */
  real_T Constant4_Value_m;            /* Expression: SM.ctrl
                                        * Referenced by: '<S14>/Constant4'
                                        */
  real_T Constant5_Value;              /* Expression: SM.ensat
                                        * Referenced by: '<S13>/Constant5'
                                        */
  real_T Lm_nosat_Value;               /* Expression: SM.Lm
                                        * Referenced by: '<S13>/Lm_nosat'
                                        */
  real_T Switch2_Threshold;            /* Expression: 0.5
                                        * Referenced by: '<S13>/Switch2'
                                        */
  real_T unitconversion_Gain[19];      /* Expression: [SM.ib2*ones(5,1);SM.phib2;SM.phib2;SM.Vb2;SM.Vb2;SM.ib2*ones(5,1);SM.phib2;SM.phib2;SM.Vb2;SM.Vb2; SM.phib2/SM.ib2]
                                        * Referenced by: '<S12>/unit conversion'
                                        */
  real_T Constant3_Value_o;            /* Expression: SM.ensat
                                        * Referenced by: '<S13>/Constant3'
                                        */
  real_T Constant4_Value_j[16];        /* Expression: SM.RLinv
                                        * Referenced by: '<S13>/Constant4'
                                        */
  real_T Constant4_Value_l;            /* Expression: SM.ctrl
                                        * Referenced by: '<S16>/Constant4'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0.5
                                        * Referenced by: '<S13>/Switch1'
                                        */
  real_T wbase_Gain;                   /* Expression: SM.web
                                        * Referenced by: '<S19>/wbase'
                                        */
  real_T _Tb2_Gain;                    /* Expression: 1/SM.Tb2
                                        * Referenced by: '<S35>/1_Tb2'
                                        */
  real_T F_Gain;                       /* Expression: SM.F
                                        * Referenced by: '<S35>/F'
                                        */
  real_T _2H_Gain;                     /* Expression: 1/(2*SM.H)
                                        * Referenced by: '<S35>/1_2H'
                                        */
  real_T web_psb_Gain_b;               /* Expression: SM.web
                                        * Referenced by: '<S35>/web_psb'
                                        */
  real_T integ1_IC;                    /* Expression: 0
                                        * Referenced by: '<S2>/integ1'
                                        */
  real_T T_InitOutput;                 /* Expression: 0
                                        * Referenced by: '<S2>/T'
                                        */
  real_T Integ2_IC;                    /* Expression: 0
                                        * Referenced by: '<S2>/Integ2'
                                        */
  real_T T1_InitOutput;                /* Expression: 0
                                        * Referenced by: '<S2>/T1'
                                        */
  real_T peak2rms_Gain;                /* Expression: 1/(sqrt(2))
                                        * Referenced by: '<Root>/peak2rms'
                                        */
  real_T donotdeletethisgain_Gain;     /* Expression: 1
                                        * Referenced by: '<S7>/do not delete this gain'
                                        */
  real_T Gain2_Gain_i;                 /* Expression: 180/pi
                                        * Referenced by: '<S2>/Gain2'
                                        */
  real_T sinnwt_Amp;                   /* Expression: 1
                                        * Referenced by: '<S2>/sin(nwt)'
                                        */
  real_T sinnwt_Bias;                  /* Expression: 0
                                        * Referenced by: '<S2>/sin(nwt)'
                                        */
  real_T sinnwt_Phase;                 /* Expression: 0
                                        * Referenced by: '<S2>/sin(nwt)'
                                        */
  real_T cosnwt_Amp;                   /* Expression: 1
                                        * Referenced by: '<S2>/cos(nwt)'
                                        */
  real_T cosnwt_Bias;                  /* Expression: 0
                                        * Referenced by: '<S2>/cos(nwt)'
                                        */
  real_T cosnwt_Phase;                 /* Expression: pi/2
                                        * Referenced by: '<S2>/cos(nwt)'
                                        */
  boolean_T Constant_Value_cs;         /* Expression: SM.ctrl==1
                                        * Referenced by: '<S16>/Constant'
                                        */
  boolean_T Constant1_Value_m;         /* Expression: SM.ctrl==2
                                        * Referenced by: '<S16>/Constant1'
                                        */
  boolean_T Constant3_Value_k;         /* Expression: SM.ctrl==3
                                        * Referenced by: '<S16>/Constant3'
                                        */
  boolean_T Constant_Value_n;          /* Expression: SM.ctrl==1
                                        * Referenced by: '<S15>/Constant'
                                        */
  boolean_T Constant1_Value_om;        /* Expression: SM.ctrl==2
                                        * Referenced by: '<S15>/Constant1'
                                        */
  boolean_T Constant2_Value_d;         /* Expression: SM.ctrl==3
                                        * Referenced by: '<S15>/Constant2'
                                        */
  boolean_T Constant_Value_j;          /* Expression: SM.ctrl==1
                                        * Referenced by: '<S14>/Constant'
                                        */
  boolean_T Constant1_Value_ox;        /* Expression: SM.ctrl==2
                                        * Referenced by: '<S14>/Constant1'
                                        */
  boolean_T Constant2_Value_e;         /* Expression: SM.ctrl==3
                                        * Referenced by: '<S14>/Constant2'
                                        */
};

extern P rtP;                          /* parameters */

/* External data declarations for dependent source files */
extern const char *RT_MEMORY_ALLOCATION_ERROR;
extern B rtB;                          /* block i/o */
extern X rtX;                          /* states (continuous) */
extern DW rtDW;                        /* states (dwork) */
extern PrevZCX rtPrevZCX;              /* prev zc states*/

/* Simulation Structure */
extern SimStruct *const rtS;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'induction_motor_drive'
 * '<S1>'   : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm'
 * '<S2>'   : 'induction_motor_drive/Fourier'
 * '<S3>'   : 'induction_motor_drive/TL (p.u.)'
 * '<S4>'   : 'induction_motor_drive/Vab'
 * '<S5>'   : 'induction_motor_drive/Vbc'
 * '<S6>'   : 'induction_motor_drive/powergui'
 * '<S7>'   : 'induction_motor_drive/vab'
 * '<S8>'   : 'induction_motor_drive/wm* (p.u.)'
 * '<S9>'   : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model'
 * '<S10>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Measurements'
 * '<S11>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Mechanical model'
 * '<S12>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous'
 * '<S13>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/Asynchronous Machine State-space model'
 * '<S14>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/abc to dq  transformation'
 * '<S15>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/dq to abc transformation'
 * '<S16>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/sin,cos'
 * '<S17>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/Asynchronous Machine State-space model/Electromagnetic Torque'
 * '<S18>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/Asynchronous Machine State-space model/Saturation'
 * '<S19>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/Asynchronous Machine State-space model/phi'
 * '<S20>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/Asynchronous Machine State-space model/Saturation/Laq=Lad'
 * '<S21>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/Asynchronous Machine State-space model/Saturation/Matrix L'
 * '<S22>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/Asynchronous Machine State-space model/Saturation/Time Constant'
 * '<S23>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/Asynchronous Machine State-space model/Saturation/phimqd'
 * '<S24>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/abc to dq  transformation/Rotor reference frame'
 * '<S25>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/abc to dq  transformation/Stationary reference frame'
 * '<S26>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/abc to dq  transformation/Synchronous reference frame'
 * '<S27>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/abc to dq  transformation/transit'
 * '<S28>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/dq to abc transformation/Rotor reference frame'
 * '<S29>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/dq to abc transformation/Stationary reference frame'
 * '<S30>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/dq to abc transformation/Synchronous reference frame'
 * '<S31>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/sin,cos/sin(beta),cos(beta),sin(th),cos(th)'
 * '<S32>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/sin,cos/sin(thr),cos(thr)'
 * '<S33>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Electrical model/Continuous/sin,cos/sin(thr),cos(thr)1'
 * '<S34>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Measurements/Single-cage SI'
 * '<S35>'  : 'induction_motor_drive/3 HP - 220 V 60 Hz - 1725 rpm/Mechanical model/Continuous Tm input'
 * '<S36>'  : 'induction_motor_drive/powergui/EquivalentModel1'
 * '<S37>'  : 'induction_motor_drive/powergui/EquivalentModel1/Sources'
 * '<S38>'  : 'induction_motor_drive/powergui/EquivalentModel1/Yout'
 * '<S39>'  : 'induction_motor_drive/vab/Model'
 * '<S40>'  : 'induction_motor_drive/vab/Model/Complex'
 */

/* user code (bottom of header file) */
extern const int_T gblNumToFiles;
extern const int_T gblNumFrFiles;
extern const int_T gblNumFrWksBlocks;
extern rtInportTUtable *gblInportTUtables;
extern const char *gblInportFileName;
extern const int_T gblNumRootInportBlks;
extern const int_T gblNumModelInputs;
extern const int_T gblInportDataTypeIdx[];
extern const int_T gblInportDims[];
extern const int_T gblInportComplex[];
extern const int_T gblInportInterpoFlag[];
extern const int_T gblInportContinuous[];

#endif                                 /* RTW_HEADER_induction_motor_drive_h_ */
