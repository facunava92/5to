/*
 * induction_motor_drive_data.c
 *
 * Code generation for model "induction_motor_drive".
 *
 * Model version              : 1.147
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Sat Feb 13 22:10:01 2016
 *
 * Target selection: rsim.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "induction_motor_drive.h"
#include "induction_motor_drive_private.h"

/* Block parameters (auto storage) */
P rtP = {
  60.0,                                /* Mask Parameter: Fourier_f1
                                        * Referenced by:
                                        *   '<S2>/Gain1'
                                        *   '<S2>/cos(nwt)'
                                        *   '<S2>/sin(nwt)'
                                        *   '<S2>/T'
                                        *   '<S2>/T1'
                                        */
  1.0,                                 /* Mask Parameter: Fourier_n
                                        * Referenced by:
                                        *   '<S2>/cos(nwt)'
                                        *   '<S2>/sin(nwt)'
                                        */
  0.0,                                 /* Expression: SM.Lsat(1)
                                        * Referenced by: '<S18>/Constant1'
                                        */

  /*  Expression: [ SM.Lls SM.Llr ]
   * Referenced by: '<S20>/u2'
   */
  { 0.069727778764303708, 0.034863889382151854 },
  0.0,                                 /* Expression: SM.Lsat(1)
                                        * Referenced by: '<S22>/Integrator'
                                        */

  /*  Expression: [1/SM.Lls 1/SM.Llr]
   * Referenced by: '<S23>/u1'
   */
  { 14.341486531217855, 28.68297306243571 },

  /*  Expression: SM.Phisat
   * Referenced by: '<S18>/Lookup Table'
   */
  { 0.0, 1.0 },

  /*  Expression: [ 0 SM.Phisat(2:end)./SM.Lsat(2:end) ]
   * Referenced by: '<S18>/Lookup Table'
   */
  { 0.0, 1.0 },

  /*  Expression: zeros(4,4)
   * Referenced by: '<S21>/u1'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0 },

  /*  Expression: SM.Ll
   * Referenced by: '<S21>/u5'
   */
  { 0.069727778764303708, 0.0, 0.0, 0.0, 0.0, 0.069727778764303708, 0.0, 0.0,
    0.0, 0.0, 0.034863889382151854, 0.0, 0.0, 0.0, 0.0, 0.034863889382151854 },

  /*  Expression: SM.R
   * Referenced by: '<S18>/u1'
   */
  { 0.020114256198347107, 0.0, 0.0, 0.0, 0.0, 0.020114256198347107, 0.0, 0.0,
    0.0, 0.0, 0.037731570247933881, 0.0, 0.0, 0.0, 0.0, 0.037731570247933881 },
  1.0E+6,                              /* Expression: 1/1e-6
                                        * Referenced by: '<S22>/1//T (T= 1e-6s)'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S24>/vqr,vdr'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S24>/vqs,vds'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S25>/vqr,vdr'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S25>/vqs,vds'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S26>/vqr,vdr'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S26>/vqs,vds'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S28>/ira,irb'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S28>/isa,isb'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S29>/ira,irb'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S29>/isa,isb'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S30>/ira,irb'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S30>/isa,isb'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S31>/sin(beta),cos(beta), sin(th),cos(th)'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S31>/W'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S31>/we'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S31>/Gain2'
                                        */
  376.99111843077515,                  /* Expression: SM.web
                                        * Referenced by: '<S31>/web_psb'
                                        */

  /*  Expression: [ 0 1  0  0; -1  0  0  0;  0  0  0  0;  0  0  0  0]
   * Referenced by: '<S31>/u3'
   */
  { 0.0, -1.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0 },
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S32>/sin(thr),cos(thr)'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S32>/W'
                                        */

  /*  Expression: [0; 0]
   * Referenced by: '<S32>/Constant'
   */
  { 0.0, 0.0 },
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S32>/Gain1'
                                        */

  /*  Expression: zeros(4,4)
   * Referenced by: '<S32>/u1'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0 },
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S33>/sin(thr),cos(thr)'
                                        */

  /*  Expression: [0; 0]
   * Referenced by: '<S33>/Constant'
   */
  { 0.0, 0.0 },
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S33>/Gain3'
                                        */

  /*  Expression: zeros(4,4)
   * Referenced by: '<S33>/u4'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0 },
  0.0,                                 /* Expression: SM.wmo
                                        * Referenced by: '<S35>/Rotor speed (wm)'
                                        */

  /*  Expression: SM.phiqd0
   * Referenced by: '<S19>/Integrator'
   */
  { 0.0, 0.0, 0.0, 0.0 },
  0.0,                                 /* Expression: SM.ensat
                                        * Referenced by: '<S13>/Constant'
                                        */
  0.0,                                 /* Expression: SM.ensat
                                        * Referenced by: '<S13>/Constant1'
                                        */

  /*  Expression: SM.Linv
   * Referenced by: '<S13>/Constant2'
   */
  { 9.6512188415150835, 0.0, -9.38053537940556, 0.0, 0.0, 9.6512188415150835,
    0.0, -9.38053537940556, -9.38053537940556, 0.0, 9.92190230362461, 0.0, 0.0,
    -9.38053537940556, 0.0, 9.92190230362461 },
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S13>/Switch'
                                        */

  /*  Expression: [1 -1]
   * Referenced by: '<S17>/1-1'
   */
  { 1.0, -1.0 },
  0.0,                                 /* Expression: SM.tho
                                        * Referenced by: '<S35>/Rotor angle thetam'
                                        */
  0.5,                                 /* Expression: 1/SM.p
                                        * Referenced by: '<S35>/1\p'
                                        */

  /*  Expression: [SM.Nb2;SM.Tb2;1]
   * Referenced by: '<S35>/Gain'
   */
  { 188.49555921538757, 11.872958754655393, 1.0 },

  /*  Computed Parameter: FromWs_Time0
   * Referenced by: '<S3>/FromWs'
   */
  { 0.0, 1.0, 1.0, 1.4000000000000001, 1.4000000000000001, 2.0 },

  /*  Computed Parameter: FromWs_Data0
   * Referenced by: '<S3>/FromWs'
   */
  { 0.0, 0.0, 10.0, 10.0, -0.05, -0.05 },
  9.5492965855137211,                  /* Expression: 30/pi
                                        * Referenced by: '<Root>/rpm'
                                        */
  2.0,                                 /* Expression: SM.ctrl
                                        * Referenced by: '<S15>/Constant3'
                                        */
  2.0,                                 /* Expression: SM.ctrl
                                        * Referenced by: '<S16>/Constant2'
                                        */
  2.0,                                 /* Expression: SM.ctrl
                                        * Referenced by: '<S14>/Constant3'
                                        */

  /*  Expression: [0;0]
   * Referenced by: '<S27>/Constant6'
   */
  { 0.0, 0.0 },
  2.0,                                 /* Expression: SM.ctrl
                                        * Referenced by: '<S15>/Constant4'
                                        */
  8.30599703689205,                    /* Expression: SM.ib
                                        * Referenced by: '<S15>/ib'
                                        */

  /*  Computed Parameter: FromWs_Time0_n
   * Referenced by: '<S8>/FromWs'
   */
  { 0.0, 1.4000000000000001, 1.4000000000000001, 2.0 },

  /*  Computed Parameter: FromWs_Data0_e
   * Referenced by: '<S8>/FromWs'
   */
  { 1.0, 1.0, 0.9, 0.9 },
  376.99111843077515,                  /* Expression: 2*pi*60
                                        * Referenced by: '<Root>/pu2radpersec'
                                        */

  /*  Expression: 2*pi/3*[ 0,-1,1 ]
   * Referenced by: '<Root>/Constant'
   */
  { 0.0, -2.0943951023931953, 2.0943951023931953 },
  0.000505050505050505,                /* Expression: 1/1980
                                        * Referenced by: '<Root>/Constant1'
                                        */

  /*  Expression: [0 0.25  0.75  1] / 1980
   * Referenced by: '<Root>/Look-Up Table'
   */
  { 0.0, 0.00012626262626262626, 0.00037878787878787879, 0.000505050505050505 },

  /*  Expression: [0  1  -1  0]
   * Referenced by: '<Root>/Look-Up Table'
   */
  { 0.0, 1.0, -1.0, 0.0 },
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/RelayA'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/RelayA'
                                        */
  179.62924780409972,                  /* Expression: 220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayA'
                                        */
  -179.62924780409972,                 /* Expression: -220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayA'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/RelayB'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/RelayB'
                                        */
  179.62924780409972,                  /* Expression: 220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayB'
                                        */
  -179.62924780409972,                 /* Expression: -220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayB'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/RelayC'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/RelayC'
                                        */
  179.62924780409972,                  /* Expression: 220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayC'
                                        */
  -179.62924780409972,                 /* Expression: -220*sqrt(2/3)
                                        * Referenced by: '<Root>/RelayC'
                                        */
  0.0055670221426890416,               /* Expression: 1/SM.Vb
                                        * Referenced by: '<S14>/1_Vb'
                                        */
  2.0,                                 /* Expression: SM.ctrl
                                        * Referenced by: '<S14>/Constant4'
                                        */
  0.0,                                 /* Expression: SM.ensat
                                        * Referenced by: '<S13>/Constant5'
                                        */
  1.2082080865384723,                  /* Expression: SM.Lm
                                        * Referenced by: '<S13>/Lm_nosat'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S13>/Switch2'
                                        */

  /*  Expression: [SM.ib2*ones(5,1);SM.phib2;SM.phib2;SM.Vb2;SM.Vb2;SM.ib2*ones(5,1);SM.phib2;SM.phib2;SM.Vb2;SM.Vb2; SM.phib2/SM.ib2]
   * Referenced by: '<S12>/unit conversion'
   */
  { 8.30599703689205, 8.30599703689205, 8.30599703689205, 8.30599703689205,
    8.30599703689205, 0.476481378531691, 0.476481378531691, 179.62924780409972,
    179.62924780409972, 8.30599703689205, 8.30599703689205, 8.30599703689205,
    8.30599703689205, 8.30599703689205, 0.476481378531691, 0.476481378531691,
    179.62924780409972, 179.62924780409972, 0.05736594612487142 },
  0.0,                                 /* Expression: SM.ensat
                                        * Referenced by: '<S13>/Constant3'
                                        */

  /*  Expression: SM.RLinv
   * Referenced by: '<S13>/Constant4'
   */
  { 0.19412708840454915, 0.0, -0.35394232963127, 0.0, 0.0, 0.19412708840454915,
    0.0, -0.35394232963127, -0.18868249189902261, 0.0, 0.37436895376234897, 0.0,
    0.0, -0.18868249189902261, 0.0, 0.37436895376234897 },
  2.0,                                 /* Expression: SM.ctrl
                                        * Referenced by: '<S16>/Constant4'
                                        */
  0.5,                                 /* Expression: 0.5
                                        * Referenced by: '<S13>/Switch1'
                                        */
  376.99111843077515,                  /* Expression: SM.web
                                        * Referenced by: '<S19>/wbase'
                                        */
  0.084225004117688823,                /* Expression: 1/SM.Tb2
                                        * Referenced by: '<S35>/1_Tb2'
                                        */
  0.0,                                 /* Expression: SM.F
                                        * Referenced by: '<S35>/F'
                                        */
  0.70773036514217225,                 /* Expression: 1/(2*SM.H)
                                        * Referenced by: '<S35>/1_2H'
                                        */
  376.99111843077515,                  /* Expression: SM.web
                                        * Referenced by: '<S35>/web_psb'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/integ1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/T'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/Integ2'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/T1'
                                        */
  0.70710678118654746,                 /* Expression: 1/(sqrt(2))
                                        * Referenced by: '<Root>/peak2rms'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S7>/do not delete this gain'
                                        */
  57.295779513082323,                  /* Expression: 180/pi
                                        * Referenced by: '<S2>/Gain2'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/sin(nwt)'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/sin(nwt)'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/sin(nwt)'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S2>/cos(nwt)'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S2>/cos(nwt)'
                                        */
  1.5707963267948966,                  /* Expression: pi/2
                                        * Referenced by: '<S2>/cos(nwt)'
                                        */
  0,                                   /* Expression: SM.ctrl==1
                                        * Referenced by: '<S16>/Constant'
                                        */
  1,                                   /* Expression: SM.ctrl==2
                                        * Referenced by: '<S16>/Constant1'
                                        */
  0,                                   /* Expression: SM.ctrl==3
                                        * Referenced by: '<S16>/Constant3'
                                        */
  0,                                   /* Expression: SM.ctrl==1
                                        * Referenced by: '<S15>/Constant'
                                        */
  1,                                   /* Expression: SM.ctrl==2
                                        * Referenced by: '<S15>/Constant1'
                                        */
  0,                                   /* Expression: SM.ctrl==3
                                        * Referenced by: '<S15>/Constant2'
                                        */
  0,                                   /* Expression: SM.ctrl==1
                                        * Referenced by: '<S14>/Constant'
                                        */
  1,                                   /* Expression: SM.ctrl==2
                                        * Referenced by: '<S14>/Constant1'
                                        */
  0                                    /* Expression: SM.ctrl==3
                                        * Referenced by: '<S14>/Constant2'
                                        */
};
