/*
 * induction_motor_drive.c
 *
 * Code generation for model "induction_motor_drive".
 *
 * Model version              : 1.147
 * Simulink Coder version : 8.6 (R2014a) 27-Dec-2013
 * C source code generated on : Sat Feb 13 22:10:01 2016
 *
 * Target selection: rsim.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Emulation hardware selection:
 *    Differs from embedded hardware (MATLAB Host)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include <math.h>
#include "induction_motor_drive.h"
#include "induction_motor_drive_private.h"
#include "induction_motor_drive_dt.h"

/* user code (top of parameter file) */
const int_T gblNumToFiles = 0;
const int_T gblNumFrFiles = 0;
const int_T gblNumFrWksBlocks = 2;
const char *gblSlvrJacPatternFileName =
  "induction_motor_drive_rsim_rtw\\induction_motor_drive_Jpattern.mat";

/* Root inports information  */
const int_T gblNumRootInportBlks = 0;
const int_T gblNumModelInputs = 0;
extern rtInportTUtable *gblInportTUtables;
extern const char *gblInportFileName;
const int_T gblInportDataTypeIdx[] = { -1 };

const int_T gblInportDims[] = { -1 } ;

const int_T gblInportComplex[] = { -1 };

const int_T gblInportInterpoFlag[] = { -1 };

const int_T gblInportContinuous[] = { -1 };

#include "simstruc.h"
#include "fixedpoint.h"

/* Block signals (auto storage) */
B rtB;

/* Continuous states */
X rtX;

/* Block states (auto storage) */
DW rtDW;

/* Parent Simstruct */
static SimStruct model_S;
SimStruct *const rtS = &model_S;

#ifndef __RTW_UTFREE__

extern void * utMalloc(size_t);

#endif

/* Time delay buffer creation routine */
void * rt_TDelayCreateBuf(
  int_T numBuffer,
  int_T bufSz,
  int_T elemSz)
{
  return((void*)utMalloc(numBuffer*bufSz*elemSz));
}

#ifndef __RTW_UTFREE__

extern void * utMalloc(size_t);
extern void utFree(void *);

#endif

/* Buffer management routine for variable delay block */
boolean_T rt_TDelayUpdateTailOrGrowBuf(
  int_T *bufSzPtr,                     /* in/out - circular buffer size                 */
  int_T *tailPtr,                      /* in/out - tail of circular buffer              */
  int_T *headPtr,                      /* in/out - head of circular buffer              */
  int_T *lastPtr,                      /* in/out - same logical 'last' referenced index */
  real_T tMinusDelay,                  /* in     - last point we are looking at   */
  real_T **tBufPtr,                    /* in/out - larger buffer for time         */
  real_T **uBufPtr,                    /* in/out - larger buffer for input        */
  real_T **xBufPtr,                    /* in/out - larger buffer for state        */
  boolean_T isfixedbuf,                /* in     - fixed buffer size enable       */
  boolean_T istransportdelay,          /* in     - block acts as transport dela y */
  int_T *maxNewBufSzPtr)
{
  int_T testIdx;
  int_T tail = *tailPtr;
  int_T bufSz = *bufSzPtr;
  real_T *tBuf = *tBufPtr;
  real_T *xBuf = (NULL);
  int_T numBuffer = 2;
  if (istransportdelay) {
    numBuffer = 3 ;
    xBuf= *xBufPtr;
  }

  /*    Get testIdx, the index of the second oldest data point and
   *    see if this is older than current sim time minus applied delay,
   *    used to see if we can move tail forward
   */
  testIdx = (tail < (bufSz - 1)) ? (tail + 1) : 0;
  if ((tMinusDelay <= tBuf[testIdx]) && !isfixedbuf) {
    int_T j;
    real_T *tempT;
    real_T *tempU;
    real_T *tempX = (NULL);
    real_T *uBuf = *uBufPtr;
    int_T newBufSz = bufSz + 1024;
    if (newBufSz > *maxNewBufSzPtr) {
      *maxNewBufSzPtr = newBufSz;      /* save for warning*/
    }

    tempU = (real_T*)utMalloc(numBuffer*newBufSz*sizeof(real_T));
    if (tempU == (NULL)) {
      return (false);
    }

    tempT = tempU + newBufSz;
    if (istransportdelay)
      tempX = tempT + newBufSz;
    for (j = tail; j < bufSz; j++) {
      tempT[j - tail] = tBuf[j];
      tempU[j - tail] = uBuf[j];
      if (istransportdelay)
        tempX[j - tail] = xBuf[j];
    }

    for (j = 0; j < tail; j++) {
      tempT[j + bufSz - tail] = tBuf[j];
      tempU[j + bufSz - tail] = uBuf[j];
      if (istransportdelay)
        tempX[j + bufSz - tail] = xBuf[j];
    }

    if (*lastPtr> tail) {
      *lastPtr -= tail;
    } else {
      *lastPtr += (bufSz - tail);
    }

    *tailPtr= 0;
    *headPtr = bufSz;
    utFree(uBuf);
    *bufSzPtr = newBufSz;
    *tBufPtr = tempT;
    *uBufPtr = tempU;
    if (istransportdelay)
      *xBufPtr = tempX;
  } else {
    *tailPtr = testIdx;                /* move tail forward */
  }

  return(true);
}

/*
 * Time delay interpolation routine
 *
 * The linear interpolation is performed using the formula:
 *
 *          (t2 - tMinusDelay)         (tMinusDelay - t1)
 * u(t)  =  ----------------- * u1  +  ------------------- * u2
 *              (t2 - t1)                  (t2 - t1)
 */
real_T rt_TDelayInterpolate(
  real_T tMinusDelay,                  /* tMinusDelay = currentSimTime - delay */
  real_T tStart,
  real_T *tBuf,
  real_T *uBuf,
  int_T bufSz,
  int_T *lastIdx,
  int_T oldestIdx,
  int_T newIdx,
  real_T initOutput,
  boolean_T discrete,
  boolean_T minorStepAndTAtLastMajorOutput)
{
  int_T i;
  real_T yout, t1, t2, u1, u2;

  /*
   * If there is only one data point in the buffer, this data point must be
   * the t= 0 and tMinusDelay > t0, it ask for something unknown. The best
   * guess if initial output as well
   */
  if ((newIdx == 0) && (oldestIdx ==0 ) && (tMinusDelay > tStart))
    return initOutput;

  /*
   * If tMinusDelay is less than zero, should output initial value
   */
  if (tMinusDelay <= tStart)
    return initOutput;

  /* For fixed buffer extrapolation:
   * if tMinusDelay is small than the time at oldestIdx, if discrete, output
   * tailptr value,  else use tailptr and tailptr+1 value to extrapolate
   * It is also for fixed buffer. Note: The same condition can happen for transport delay block where
   * use tStart and and t[tail] other than using t[tail] and t[tail+1].
   * See below
   */
  if ((tMinusDelay <= tBuf[oldestIdx] ) ) {
    if (discrete) {
      return(uBuf[oldestIdx]);
    } else {
      int_T tempIdx= oldestIdx + 1;
      if (oldestIdx == bufSz-1)
        tempIdx = 0;
      t1= tBuf[oldestIdx];
      t2= tBuf[tempIdx];
      u1= uBuf[oldestIdx];
      u2= uBuf[tempIdx];
      if (t2 == t1) {
        if (tMinusDelay >= t2) {
          yout = u2;
        } else {
          yout = u1;
        }
      } else {
        real_T f1 = (t2-tMinusDelay) / (t2-t1);
        real_T f2 = 1.0 - f1;

        /*
         * Use Lagrange's interpolation formula.  Exact outputs at t1, t2.
         */
        yout = f1*u1 + f2*u2;
      }

      return yout;
    }
  }

  /*
   * When block does not have direct feedthrough, we use the table of
   * values to extrapolate off the end of the table for delays that are less
   * than 0 (less then step size).  This is not completely accurate.  The
   * chain of events is as follows for a given time t.  Major output - look
   * in table.  Update - add entry to table.  Now, if we call the output at
   * time t again, there is a new entry in the table. For very small delays,
   * this means that we will have a different answer from the previous call
   * to the output fcn at the same time t.  The following code prevents this
   * from happening.
   */
  if (minorStepAndTAtLastMajorOutput) {
    /* pretend that the new entry has not been added to table */
    if (newIdx != 0) {
      if (*lastIdx == newIdx) {
        (*lastIdx)--;
      }

      newIdx--;
    } else {
      if (*lastIdx == newIdx) {
        *lastIdx = bufSz-1;
      }

      newIdx = bufSz - 1;
    }
  }

  i = *lastIdx;
  if (tBuf[i] < tMinusDelay) {
    /* Look forward starting at last index */
    while (tBuf[i] < tMinusDelay) {
      /* May occur if the delay is less than step-size - extrapolate */
      if (i == newIdx)
        break;
      i = ( i < (bufSz-1) ) ? (i+1) : 0;/* move through buffer */
    }
  } else {
    /*
     * Look backwards starting at last index which can happen when the
     * delay time increases.
     */
    while (tBuf[i] >= tMinusDelay) {
      /*
       * Due to the entry condition at top of function, we
       * should never hit the end.
       */
      i = (i > 0) ? i-1 : (bufSz-1);   /* move through buffer */
    }

    i = ( i < (bufSz-1) ) ? (i+1) : 0;
  }

  *lastIdx = i;
  if (discrete) {
    /*
     * tempEps = 128 * eps;
     * localEps = max(tempEps, tempEps*fabs(tBuf[i]))/2;
     */
    double tempEps = (DBL_EPSILON) * 128.0;
    double localEps = tempEps * fabs(tBuf[i]);
    if (tempEps > localEps) {
      localEps = tempEps;
    }

    localEps = localEps / 2.0;
    if (tMinusDelay >= (tBuf[i] - localEps)) {
      yout = uBuf[i];
    } else {
      if (i == 0) {
        yout = uBuf[bufSz-1];
      } else {
        yout = uBuf[i-1];
      }
    }
  } else {
    if (i == 0) {
      t1 = tBuf[bufSz-1];
      u1 = uBuf[bufSz-1];
    } else {
      t1 = tBuf[i-1];
      u1 = uBuf[i-1];
    }

    t2 = tBuf[i];
    u2 = uBuf[i];
    if (t2 == t1) {
      if (tMinusDelay >= t2) {
        yout = u2;
      } else {
        yout = u1;
      }
    } else {
      real_T f1 = (t2-tMinusDelay) / (t2-t1);
      real_T f2 = 1.0 - f1;

      /*
       * Use Lagrange's interpolation formula.  Exact outputs at t1, t2.
       */
      yout = f1*u1 + f2*u2;
    }
  }

  return(yout);
}

#ifndef __RTW_UTFREE__

extern void utFree(void *);

#endif

/* Time delay buffer deletion routine */
void rt_TDelayFreeBuf(
                      void * buf)
{
  utFree(buf);
}

real_T rt_hypotd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T a;
  real_T b;
  a = fabs(u0);
  b = fabs(u1);
  if (a < b) {
    a /= b;
    y = sqrt(a * a + 1.0) * b;
  } else if (a > b) {
    b /= a;
    y = sqrt(b * b + 1.0) * a;
  } else if (rtIsNaN(b)) {
    y = b;
  } else {
    y = a * 1.4142135623730951;
  }

  return y;
}

void rt_invd4x4_snf(const real_T u[16], real_T y[16])
{
  int8_T p[4];
  real_T A[16];
  int8_T ipiv[4];
  int32_T jj;
  int32_T j;
  int32_T c;
  int32_T ix;
  real_T smax;
  real_T s;
  int32_T jA;
  int32_T jBcol;
  int32_T i;
  int32_T i_0;
  for (i_0 = 0; i_0 < 16; i_0++) {
    y[i_0] = 0.0;
    A[i_0] = u[i_0];
  }

  ipiv[0] = 1;
  ipiv[1] = 2;
  ipiv[2] = 3;
  for (j = 0; j < 3; j++) {
    c = j * 5;
    jj = j * 5;
    jBcol = 1;
    ix = c;
    smax = fabs(A[jj]);
    for (jA = 2; jA <= 4 - j; jA++) {
      ix++;
      s = fabs(A[ix]);
      if (s > smax) {
        jBcol = jA;
        smax = s;
      }
    }

    jBcol--;
    if (A[c + jBcol] != 0.0) {
      if (jBcol != 0) {
        ipiv[j] = (int8_T)((j + jBcol) + 1);
        jBcol += j;
        smax = A[j];
        A[j] = A[jBcol];
        A[jBcol] = smax;
        ix = j + 4;
        jBcol += 4;
        smax = A[ix];
        A[ix] = A[jBcol];
        A[jBcol] = smax;
        ix += 4;
        jBcol += 4;
        smax = A[ix];
        A[ix] = A[jBcol];
        A[jBcol] = smax;
        ix += 4;
        jBcol += 4;
        smax = A[ix];
        A[ix] = A[jBcol];
        A[jBcol] = smax;
      }

      i_0 = c - j;
      for (i = c + 1; i + 1 <= i_0 + 4; i++) {
        A[i] /= A[c];
      }
    }

    jA = jj;
    jBcol = jj + 4;
    for (jj = 1; jj <= 3 - j; jj++) {
      if (A[jBcol] != 0.0) {
        smax = -A[jBcol];
        ix = c;
        i_0 = jA - j;
        for (i = jA + 5; i + 1 <= i_0 + 8; i++) {
          A[i] += A[ix + 1] * smax;
          ix++;
        }
      }

      jBcol += 4;
      jA += 4;
    }
  }

  p[0] = 1;
  p[1] = 2;
  p[2] = 3;
  p[3] = 4;
  if (ipiv[0] > 1) {
    jBcol = p[ipiv[0] - 1];
    p[ipiv[0] - 1] = 1;
    p[0] = (int8_T)jBcol;
  }

  if (ipiv[1] > 2) {
    jBcol = p[ipiv[1] - 1];
    p[ipiv[1] - 1] = p[1];
    p[1] = (int8_T)jBcol;
  }

  if (ipiv[2] > 3) {
    jBcol = p[ipiv[2] - 1];
    p[ipiv[2] - 1] = p[2];
    p[2] = (int8_T)jBcol;
  }

  y[(p[0] - 1) << 2] = 1.0;
  for (j = 0; j + 1 < 5; j++) {
    if (y[((p[0] - 1) << 2) + j] != 0.0) {
      for (i = j + 1; i + 1 < 5; i++) {
        y[i + ((p[0] - 1) << 2)] -= y[((p[0] - 1) << 2) + j] * A[(j << 2) + i];
      }
    }
  }

  y[1 + ((p[1] - 1) << 2)] = 1.0;
  for (j = 1; j + 1 < 5; j++) {
    if (y[((p[1] - 1) << 2) + j] != 0.0) {
      for (i = j + 1; i + 1 < 5; i++) {
        y[i + ((p[1] - 1) << 2)] -= y[((p[1] - 1) << 2) + j] * A[(j << 2) + i];
      }
    }
  }

  y[2 + ((p[2] - 1) << 2)] = 1.0;
  for (j = 2; j + 1 < 5; j++) {
    if (y[((p[2] - 1) << 2) + j] != 0.0) {
      for (i = j + 1; i + 1 < 5; i++) {
        y[i + ((p[2] - 1) << 2)] -= y[((p[2] - 1) << 2) + j] * A[(j << 2) + i];
      }
    }
  }

  y[3 + ((p[3] - 1) << 2)] = 1.0;
  for (j = 3; j + 1 < 5; j++) {
    if (y[((p[3] - 1) << 2) + j] != 0.0) {
      for (i = j + 1; i + 1 < 5; i++) {
        y[i + ((p[3] - 1) << 2)] -= y[((p[3] - 1) << 2) + j] * A[(j << 2) + i];
      }
    }
  }

  for (j = 0; j < 4; j++) {
    jBcol = j << 2;
    if (y[3 + jBcol] != 0.0) {
      y[3 + jBcol] /= A[15];
      for (i = 0; i + 1 < 4; i++) {
        y[i + jBcol] -= y[3 + jBcol] * A[i + 12];
      }
    }

    if (y[2 + jBcol] != 0.0) {
      y[2 + jBcol] /= A[10];
      for (i = 0; i + 1 < 3; i++) {
        y[i + jBcol] -= y[2 + jBcol] * A[i + 8];
      }
    }

    if (y[1 + jBcol] != 0.0) {
      y[1 + jBcol] /= A[5];
      for (i = 0; i + 1 < 2; i++) {
        y[i + jBcol] -= y[1 + jBcol] * A[i + 4];
      }
    }

    if (y[jBcol] != 0.0) {
      y[jBcol] /= A[0];
    }
  }
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

real_T rt_remd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T u1_0;
  if (!((!rtIsNaN(u0)) && (!rtIsInf(u0)) && ((!rtIsNaN(u1)) && (!rtIsInf(u1)))))
  {
    y = (rtNaN);
  } else {
    if (u1 < 0.0) {
      u1_0 = ceil(u1);
    } else {
      u1_0 = floor(u1);
    }

    if ((u1 != 0.0) && (u1 != u1_0)) {
      u1_0 = u0 / u1;
      if (fabs(u1_0 - rt_roundd_snf(u1_0)) <= DBL_EPSILON * fabs(u1_0)) {
        y = 0.0;
      } else {
        y = fmod(u0, u1);
      }
    } else {
      y = fmod(u0, u1);
    }
  }

  return y;
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  int32_T u0_0;
  int32_T u1_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u0 > 0.0) {
      u0_0 = 1;
    } else {
      u0_0 = -1;
    }

    if (u1 > 0.0) {
      u1_0 = 1;
    } else {
      u1_0 = -1;
    }

    y = atan2(u0_0, u1_0);
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

/* Initial conditions for root system: '<Root>' */
void MdlInitialize(void)
{
  /* InitializeConditions for Integrator: '<S35>/Rotor speed (wm)' */
  rtX.Rotorspeedwm_CSTATE = rtP.Rotorspeedwm_IC;

  /* InitializeConditions for Integrator: '<S19>/Integrator' */
  rtX.Integrator_CSTATE[0] = (rtP.Integrator_IC_o[0]);
  rtX.Integrator_CSTATE[1] = (rtP.Integrator_IC_o[1]);
  rtX.Integrator_CSTATE[2] = (rtP.Integrator_IC_o[2]);
  rtX.Integrator_CSTATE[3] = (rtP.Integrator_IC_o[3]);

  /* InitializeConditions for Integrator: '<S35>/Rotor angle thetam' */
  rtX.Rotoranglethetam_CSTATE = rtP.Rotoranglethetam_IC;

  /* InitializeConditions for S-Function (sfun_spssw_contc): '<S36>/State-Space' */
  {
    real_T *As = (real_T*)rtDW.StateSpace_PWORK.AS;
    real_T *Bs = (real_T*)rtDW.StateSpace_PWORK.BS;
    real_T *Cs = (real_T*)rtDW.StateSpace_PWORK.CS;
    real_T *Ds = (real_T*)rtDW.StateSpace_PWORK.DS;
    int_T *Chopper = (int_T*) rtDW.StateSpace_PWORK.CHOPPER;

    /* Copy and transpose A and B */
    Ds[0] = 0.0;
    Ds[1] = 0.0;
    Ds[2] = 1.0;
    Ds[3] = 0.0;
    Ds[4] = 0.0;
    Ds[5] = 0.0;
    Ds[6] = 0.0;
    Ds[7] = 1.0;
    Ds[8] = 0.0;
    Ds[9] = 0.0;
    Ds[10] = 1.0;
    Ds[11] = 0.0;
  }

  /* InitializeConditions for Integrator: '<S2>/integ1' */
  rtX.integ1_CSTATE = rtP.integ1_IC;

  /* InitializeConditions for Integrator: '<S2>/Integ2' */
  rtX.Integ2_CSTATE = rtP.Integ2_IC;
}

/* Start for root system: '<Root>' */
void MdlStart(void)
{
  int32_T i;

  /* Start for Enabled SubSystem: '<S13>/Saturation' */
  rtDW.Saturation_MODE = false;
  ssSetSolverNeedsReset(rtS);
  ((XDis *) ssGetContStateDisabled(rtS))->Integrator_CSTATE_k = 1;

  /* End of Start for SubSystem: '<S13>/Saturation' */

  /* InitializeConditions for Enabled SubSystem: '<S13>/Saturation' */

  /* InitializeConditions for Integrator: '<S22>/Integrator' */
  rtX.Integrator_CSTATE_k = rtP.Integrator_IC;

  /* End of InitializeConditions for SubSystem: '<S13>/Saturation' */

  /* Start for FromWorkspace: '<S3>/FromWs' */
  {
    FWksInfo *fromwksInfo;
    if ((fromwksInfo = (FWksInfo *) calloc(1, sizeof(FWksInfo))) == (NULL)) {
      ssSetErrorStatus(rtS,
                       "from workspace STRING(Name) memory allocation error");
    } else {
      fromwksInfo->origWorkspaceVarName = "tuvar";
      fromwksInfo->origDataTypeId = 0;
      fromwksInfo->origIsComplex = 0;
      fromwksInfo->origWidth = 1;
      fromwksInfo->origElSize = sizeof(real_T);
      fromwksInfo->data = (void *)rtP.FromWs_Data0;
      fromwksInfo->nDataPoints = 6;
      fromwksInfo->time = (double *)rtP.FromWs_Time0;
      rtDW.FromWs_PWORK.TimePtr = fromwksInfo->time;
      rtDW.FromWs_PWORK.DataPtr = fromwksInfo->data;
      rtDW.FromWs_PWORK.RSimInfoPtr = fromwksInfo;
    }

    rtDW.FromWs_IWORK.PrevIndex = 0;

    {
      int_T* zcTimeIndices = &rtDW.FromWs_ZCTimeIndices[0];
      const double* timePoints = (double*) rtDW.FromWs_PWORK.TimePtr;
      boolean_T justHadZcTime = false;
      int_T zcIdx = 0;
      int_T i;
      for (i = 0; i < 6-1; i++) {
        if (!justHadZcTime && timePoints[i] == timePoints[i+1]) {
          zcTimeIndices[zcIdx++] = i;
          justHadZcTime = true;
        } else {
          justHadZcTime = false;
        }
      }

      rtDW.FromWs_CurZCTimeIndIdx = 0;
    }
  }

  /* Start for Enabled SubSystem: '<S16>/sin(thr),cos(thr)' */
  rtDW.sinthrcosthr_MODE = false;
  ssSetSolverNeedsReset(rtS);

  /* VirtualOutportStart for Outport: '<S32>/sin(thr),cos(thr)' */
  rtB.TrigonometricFunction_i = rtP.sinthrcosthr_Y0;
  rtB.TrigonometricFunction1_c = rtP.sinthrcosthr_Y0;
  rtB.Constant_c[0] = rtP.sinthrcosthr_Y0;
  rtB.Constant_c[1] = rtP.sinthrcosthr_Y0;

  /* VirtualOutportStart for Outport: '<S32>/W' */
  for (i = 0; i < 16; i++) {
    rtB.W21wr[i] = rtP.W_Y0_d;
  }

  /* End of VirtualOutportStart for Outport: '<S32>/W' */
  /* End of Start for SubSystem: '<S16>/sin(thr),cos(thr)' */

  /* Start for Enabled SubSystem: '<S16>/sin(thr),cos(thr)1' */
  rtDW.sinthrcosthr1_MODE = false;
  ssSetSolverNeedsReset(rtS);

  /* VirtualOutportStart for Outport: '<S33>/sin(thr),cos(thr)' */
  rtB.TrigonometricFunction = rtP.sinthrcosthr_Y0_f;
  rtB.TrigonometricFunction1 = rtP.sinthrcosthr_Y0_f;
  rtB.Constant[0] = rtP.sinthrcosthr_Y0_f;
  rtB.Constant[1] = rtP.sinthrcosthr_Y0_f;

  /* End of Start for SubSystem: '<S16>/sin(thr),cos(thr)1' */

  /* Start for Enabled SubSystem: '<S16>/sin(beta),cos(beta),sin(th),cos(th)' */
  rtDW.sinbetacosbetasinthcosth_MODE = false;
  ssSetSolverNeedsReset(rtS);

  /* VirtualOutportStart for Outport: '<S31>/sin(beta),cos(beta), sin(th),cos(th)' */
  rtB.TrigonometricFunction1_m = rtP.sinbetacosbetasinthcosth_Y0;
  rtB.TrigonometricFunction2 = rtP.sinbetacosbetasinthcosth_Y0;
  rtB.TrigonometricFunction_b = rtP.sinbetacosbetasinthcosth_Y0;
  rtB.TrigonometricFunction3 = rtP.sinbetacosbetasinthcosth_Y0;

  /* VirtualOutportStart for Outport: '<S31>/W' */
  for (i = 0; i < 16; i++) {
    rtB.W43wr1[i] = rtP.W_Y0;
  }

  /* End of VirtualOutportStart for Outport: '<S31>/W' */
  /* End of Start for SubSystem: '<S16>/sin(beta),cos(beta),sin(th),cos(th)' */

  /* Start for Enabled SubSystem: '<S15>/Rotor reference frame' */
  rtDW.Rotorreferenceframe_MODE = false;
  ssSetSolverNeedsReset(rtS);

  /* VirtualOutportStart for Outport: '<S28>/ira,irb' */
  rtB.ira_d = rtP.irairb_Y0;
  rtB.irb_c = rtP.irairb_Y0;

  /* VirtualOutportStart for Outport: '<S28>/isa,isb' */
  rtB.isa_b = rtP.isaisb_Y0;
  rtB.isb_p = rtP.isaisb_Y0;

  /* End of Start for SubSystem: '<S15>/Rotor reference frame' */

  /* Start for Enabled SubSystem: '<S15>/Stationary reference frame' */
  rtDW.Stationaryreferenceframe_MODE = false;
  ssSetSolverNeedsReset(rtS);

  /* VirtualOutportStart for Outport: '<S29>/ira,irb' */
  rtB.ira_c = rtP.irairb_Y0_k;
  rtB.irb_o = rtP.irairb_Y0_k;

  /* VirtualOutportStart for Outport: '<S29>/isa,isb' */
  rtB.isa_m = rtP.isaisb_Y0_n;
  rtB.isb_h = rtP.isaisb_Y0_n;

  /* End of Start for SubSystem: '<S15>/Stationary reference frame' */

  /* Start for Enabled SubSystem: '<S15>/Synchronous reference frame' */
  rtDW.Synchronousreferenceframe_MODE = false;
  ssSetSolverNeedsReset(rtS);

  /* VirtualOutportStart for Outport: '<S30>/ira,irb' */
  rtB.ira = rtP.irairb_Y0_j;
  rtB.irb = rtP.irairb_Y0_j;

  /* VirtualOutportStart for Outport: '<S30>/isa,isb' */
  rtB.isa = rtP.isaisb_Y0_c;
  rtB.isb = rtP.isaisb_Y0_c;

  /* End of Start for SubSystem: '<S15>/Synchronous reference frame' */
  /* Start for FromWorkspace: '<S8>/FromWs' */
  {
    FWksInfo *fromwksInfo;
    if ((fromwksInfo = (FWksInfo *) calloc(1, sizeof(FWksInfo))) == (NULL)) {
      ssSetErrorStatus(rtS,
                       "from workspace STRING(Name) memory allocation error");
    } else {
      fromwksInfo->origWorkspaceVarName = "tuvar";
      fromwksInfo->origDataTypeId = 0;
      fromwksInfo->origIsComplex = 0;
      fromwksInfo->origWidth = 1;
      fromwksInfo->origElSize = sizeof(real_T);
      fromwksInfo->data = (void *)rtP.FromWs_Data0_e;
      fromwksInfo->nDataPoints = 4;
      fromwksInfo->time = (double *)rtP.FromWs_Time0_n;
      rtDW.FromWs_PWORK_b.TimePtr = fromwksInfo->time;
      rtDW.FromWs_PWORK_b.DataPtr = fromwksInfo->data;
      rtDW.FromWs_PWORK_b.RSimInfoPtr = fromwksInfo;
    }

    rtDW.FromWs_IWORK_p.PrevIndex = 0;

    {
      int_T* zcTimeIndices = &rtDW.FromWs_ZCTimeIndices_c;
      const double* timePoints = (double*) rtDW.FromWs_PWORK_b.TimePtr;
      boolean_T justHadZcTime = false;
      int_T zcIdx = 0;
      int_T i;
      for (i = 0; i < 4-1; i++) {
        if (!justHadZcTime && timePoints[i] == timePoints[i+1]) {
          zcTimeIndices[zcIdx++] = i;
          justHadZcTime = true;
        } else {
          justHadZcTime = false;
        }
      }

      rtDW.FromWs_CurZCTimeIndIdx_f = 0;
    }
  }

  /* S-Function block: <S36>/State-Space */
  {
    rtDW.StateSpace_PWORK.AS = (real_T*)calloc(0 * 0, sizeof(real_T));
    rtDW.StateSpace_PWORK.BS = (real_T*)calloc(0 * 4, sizeof(real_T));
    rtDW.StateSpace_PWORK.CS = (real_T*)calloc(3 * 0, sizeof(real_T));
    rtDW.StateSpace_PWORK.DS = (real_T*)calloc(3 * 4, sizeof(real_T));
    rtDW.StateSpace_PWORK.DX_COL = (real_T*)calloc(3, sizeof(real_T));
    rtDW.StateSpace_PWORK.BD_COL = (real_T*)calloc(0, sizeof(real_T));
    rtDW.StateSpace_PWORK.TMP1 = (real_T*)calloc(0, sizeof(real_T));
    rtDW.StateSpace_PWORK.TMP2 = (real_T*)calloc(4, sizeof(real_T));
  }

  /* Start for Enabled SubSystem: '<S14>/Rotor reference frame' */
  rtDW.Rotorreferenceframe_MODE_g = false;
  ssSetSolverNeedsReset(rtS);

  /* VirtualOutportStart for Outport: '<S24>/vqr,vdr' */
  rtB.vqr_b = rtP.vqrvdr_Y0;
  rtB.vdr_ex = rtP.vqrvdr_Y0;

  /* VirtualOutportStart for Outport: '<S24>/vqs,vds' */
  rtB.vqs_mg = rtP.vqsvds_Y0;
  rtB.vds_p = rtP.vqsvds_Y0;

  /* End of Start for SubSystem: '<S14>/Rotor reference frame' */

  /* Start for Enabled SubSystem: '<S14>/Stationary reference frame' */
  rtDW.Stationaryreferenceframe_MODE_a = false;
  ssSetSolverNeedsReset(rtS);

  /* VirtualOutportStart for Outport: '<S25>/vqr,vdr' */
  rtB.vqr_j = rtP.vqrvdr_Y0_h;
  rtB.vdr_e = rtP.vqrvdr_Y0_h;

  /* VirtualOutportStart for Outport: '<S25>/vqs,vds' */
  rtB.vqs_m = rtP.vqsvds_Y0_g;
  rtB.vds_o = rtP.vqsvds_Y0_g;

  /* End of Start for SubSystem: '<S14>/Stationary reference frame' */

  /* Start for Enabled SubSystem: '<S14>/Synchronous reference frame' */
  rtDW.Synchronousreferenceframe_MOD_l = false;
  ssSetSolverNeedsReset(rtS);

  /* VirtualOutportStart for Outport: '<S26>/vqr,vdr' */
  rtB.vqr = rtP.vqrvdr_Y0_m;
  rtB.vdr = rtP.vqrvdr_Y0_m;

  /* VirtualOutportStart for Outport: '<S26>/vqs,vds' */
  rtB.vqs = rtP.vqsvds_Y0_h;
  rtB.vds = rtP.vqsvds_Y0_h;

  /* End of Start for SubSystem: '<S14>/Synchronous reference frame' */
  /* Start for TransportDelay: '<S2>/T' */
  {
    {
      real_T *pBuffer = (real_T *)rt_TDelayCreateBuf(2, 2048, sizeof(real_T));
      if (pBuffer == (NULL)) {
        ssSetErrorStatus(rtS, "tdelay memory allocation error");
        return;
      }

      rtDW.T_IWORK.Tail = 0;
      rtDW.T_IWORK.Head = 0;
      rtDW.T_IWORK.Last = 0;
      rtDW.T_IWORK.CircularBufSize = 2048;
      pBuffer[0] = rtP.T_InitOutput;
      pBuffer[2048] = ssGetT(rtS);
      rtDW.T_PWORK.TUbufferPtrs[0] = (void *) &pBuffer[0];
      rtDW.T_PWORK.TUbufferPtrs[1] = (void *) &pBuffer[2048];
    }
  }

  /* Start for TransportDelay: '<S2>/T1' */
  {
    {
      real_T *pBuffer = (real_T *)rt_TDelayCreateBuf(2, 2048, sizeof(real_T));
      if (pBuffer == (NULL)) {
        ssSetErrorStatus(rtS, "tdelay memory allocation error");
        return;
      }

      rtDW.T1_IWORK.Tail = 0;
      rtDW.T1_IWORK.Head = 0;
      rtDW.T1_IWORK.Last = 0;
      rtDW.T1_IWORK.CircularBufSize = 2048;
      pBuffer[0] = rtP.T1_InitOutput;
      pBuffer[2048] = ssGetT(rtS);
      rtDW.T1_PWORK.TUbufferPtrs[0] = (void *) &pBuffer[0];
      rtDW.T1_PWORK.TUbufferPtrs[1] = (void *) &pBuffer[2048];
    }
  }

  /* Start for Sqrt: '<S2>/Sqrt' */
  rtDW.Sqrt_DWORK1 = 0;
  MdlInitialize();
}

/* Outputs for root system: '<Root>' */
void MdlOutputs(int_T tid)
{
  /* local block i/o variables */
  real_T rtb_Gain2;
  real_T rtb_Gain[3];
  real_T rtb_unitconversion[19];
  real_T rtb_Clock;
  real_T rtb_FromWs;
  real_T rtb_Sum2;
  real_T rtb_peak2rms;
  real_T rtb_Sum2_b;
  real_T rtb_cosnwt;
  real_T rtb_MathFunction1_k;
  real_T rtb_Lminrows13col13[16];
  int32_T i;
  int32_T i_0;
  real_T tmp;

  /* Integrator: '<S35>/Rotor speed (wm)' */
  rtB.Rotorspeedwm = rtX.Rotorspeedwm_CSTATE;

  /* Integrator: '<S19>/Integrator' */
  rtB.Integrator[0] = rtX.Integrator_CSTATE[0];
  rtB.Integrator[1] = rtX.Integrator_CSTATE[1];
  rtB.Integrator[2] = rtX.Integrator_CSTATE[2];
  rtB.Integrator[3] = rtX.Integrator_CSTATE[3];

  /* Outputs for Enabled SubSystem: '<S13>/Saturation' incorporates:
   *  EnablePort: '<S18>/Enable'
   */
  if (ssIsSampleHit(rtS, 1, 0) && ssIsMajorTimeStep(rtS)) {
    /* Constant: '<S13>/Constant' */
    if (rtP.Constant_Value_i > 0.0) {
      if (!rtDW.Saturation_MODE) {
        ((XDis *) ssGetContStateDisabled(rtS))->Integrator_CSTATE_k = 0;
        if (ssGetTaskTime(rtS,1) != ssGetTStart(rtS)) {
          ssSetSolverNeedsReset(rtS);
        }

        rtDW.Saturation_MODE = true;
      }
    } else {
      if (rtDW.Saturation_MODE) {
        ssSetSolverNeedsReset(rtS);
        ((XDis *) ssGetContStateDisabled(rtS))->Integrator_CSTATE_k = 1;
        rtDW.Saturation_MODE = false;
      }
    }

    /* End of Constant: '<S13>/Constant' */
  }

  if (rtDW.Saturation_MODE) {
    /* Integrator: '<S22>/Integrator' */
    rtB.Integrator_g = rtX.Integrator_CSTATE_k;

    /* SignalConversion: '<S20>/TmpSignal ConversionAtMath FunctionInport1' incorporates:
     *  Constant: '<S20>/u2'
     */
    rtB.TmpSignalConversionAtMathFuncti[0] = rtP.u2_Value[0];
    rtB.TmpSignalConversionAtMathFuncti[1] = rtP.u2_Value[1];
    rtB.TmpSignalConversionAtMathFuncti[2] = rtB.Integrator_g;

    /* Sum: '<S20>/Sum2' incorporates:
     *  Math: '<S20>/Math Function'
     *
     * About '<S20>/Math Function':
     *  Operator: reciprocal
     */
    rtB.Sum2_f = (1.0 / rtB.TmpSignalConversionAtMathFuncti[0] + 1.0 /
                  rtB.TmpSignalConversionAtMathFuncti[1]) + 1.0 /
      rtB.TmpSignalConversionAtMathFuncti[2];

    /* Math: '<S20>/Math Function1'
     *
     * About '<S20>/Math Function1':
     *  Operator: reciprocal
     */
    rtb_MathFunction1_k = 1.0 / rtB.Sum2_f;

    /* Product: '<S23>/Product2' incorporates:
     *  Constant: '<S23>/u1'
     */
    rtB.Product2[0] = rtP.u1_Value[0] * rtb_MathFunction1_k;
    rtB.Product2[1] = rtP.u1_Value[1] * rtb_MathFunction1_k;

    /* Product: '<S23>/Product' */
    rtB.Product_a[0] = rtB.Integrator[0] * rtB.Product2[0];
    rtB.Product_a[1] = rtB.Integrator[2] * rtB.Product2[1];

    /* Sum: '<S23>/Sum2' */
    rtB.phimq = rtB.Product_a[0] + rtB.Product_a[1];

    /* Product: '<S23>/Product1' */
    rtB.Product1_ia[0] = rtB.Integrator[1] * rtB.Product2[0];
    rtB.Product1_ia[1] = rtB.Integrator[3] * rtB.Product2[1];

    /* Sum: '<S23>/Sum1' */
    rtB.phimd = rtB.Product1_ia[0] + rtB.Product1_ia[1];

    /* Math: '<S18>/Math Function' */
    rtb_MathFunction1_k = rt_hypotd_snf(rtB.phimq, rtB.phimd);

    /* Lookup: '<S18>/Lookup Table' */
    rtB.Isat = rt_Lookup(rtP.LookupTable_XData, 2, rtb_MathFunction1_k,
                         rtP.LookupTable_YData);

    /* Switch: '<S18>/Switch' incorporates:
     *  Constant: '<S18>/Constant1'
     */
    if (ssIsMajorTimeStep(rtS)) {
      rtDW.Switch_Mode = (rtB.Isat != 0.0);
    }

    if (rtDW.Switch_Mode) {
      /* Product: '<S18>/Product' */
      rtB.Lm_e = rtb_MathFunction1_k / rtB.Isat;
      rtB.Lm = rtB.Lm_e;
    } else {
      rtB.Lm = rtP.Constant1_Value;
    }

    /* End of Switch: '<S18>/Switch' */

    /* Assignment: '<S21>/Lm in rows[1,3] & col[1,3]' incorporates:
     *  Constant: '<S21>/u1'
     */
    memcpy(&rtb_Lminrows13col13[0], &rtP.u1_Value_b[0], sizeof(real_T) << 4U);
    rtb_Lminrows13col13[0] = rtB.Lm;
    rtb_Lminrows13col13[2] = rtB.Lm;
    rtb_Lminrows13col13[8] = rtB.Lm;
    rtb_Lminrows13col13[10] = rtB.Lm;

    /* Assignment: '<S21>/Lm in rows[2,4] & col[2,4]' */
    rtb_Lminrows13col13[5] = rtB.Lm;
    rtb_Lminrows13col13[7] = rtB.Lm;
    rtb_Lminrows13col13[13] = rtB.Lm;
    rtb_Lminrows13col13[15] = rtB.Lm;

    /* Sum: '<S21>/Sum2' incorporates:
     *  Constant: '<S21>/u5'
     */
    for (i = 0; i < 16; i++) {
      rtB.Sum2_c[i] = rtb_Lminrows13col13[i] + rtP.u5_Value[i];
    }

    /* End of Sum: '<S21>/Sum2' */

    /* Product: '<S18>/inversion' */
    rt_invd4x4_snf(rtB.Sum2_c, rtB.Linv_m);

    /* Product: '<S18>/Product1' incorporates:
     *  Constant: '<S18>/u1'
     */
    for (i = 0; i < 4; i++) {
      for (i_0 = 0; i_0 < 4; i_0++) {
        rtB.RLinv_p[i + (i_0 << 2)] = 0.0;
        rtB.RLinv_p[i + (i_0 << 2)] += rtB.Linv_m[i_0 << 2] * rtP.u1_Value_f[i];
        rtB.RLinv_p[i + (i_0 << 2)] += rtB.Linv_m[(i_0 << 2) + 1] *
          rtP.u1_Value_f[i + 4];
        rtB.RLinv_p[i + (i_0 << 2)] += rtB.Linv_m[(i_0 << 2) + 2] *
          rtP.u1_Value_f[i + 8];
        rtB.RLinv_p[i + (i_0 << 2)] += rtB.Linv_m[(i_0 << 2) + 3] *
          rtP.u1_Value_f[i + 12];
      }
    }

    /* End of Product: '<S18>/Product1' */

    /* Sum: '<S22>/Add' */
    rtB.Add = rtB.Lm - rtB.Integrator_g;

    /* Gain: '<S22>/1//T (T= 1e-6s)' */
    rtB.TT1e6s = rtP.TT1e6s_Gain * rtB.Add;
  }

  /* End of Outputs for SubSystem: '<S13>/Saturation' */

  /* Switch: '<S13>/Switch' incorporates:
   *  Constant: '<S13>/Constant1'
   *  Constant: '<S13>/Constant2'
   */
  for (i = 0; i < 16; i++) {
    if (rtP.Constant1_Value_o >= rtP.Switch_Threshold) {
      rtB.Linv[i] = rtB.Linv_m[i];
    } else {
      rtB.Linv[i] = rtP.Constant2_Value[i];
    }
  }

  /* End of Switch: '<S13>/Switch' */

  /* Product: '<S13>/Product3' */
  for (i = 0; i < 4; i++) {
    rtB.Product3[i] = 0.0;
    rtB.Product3[i] += rtB.Linv[i] * rtB.Integrator[0];
    rtB.Product3[i] += rtB.Linv[i + 4] * rtB.Integrator[1];
    rtB.Product3[i] += rtB.Linv[i + 8] * rtB.Integrator[2];
    rtB.Product3[i] += rtB.Linv[i + 12] * rtB.Integrator[3];
  }

  /* End of Product: '<S13>/Product3' */

  /* Gain: '<S17>/1-1' */
  rtB.iqsids[0] = rtP.u_Gain[0] * rtB.Product3[0];
  rtB.iqsids[1] = rtP.u_Gain[1] * rtB.Product3[1];

  /* Product: '<S17>/Mult1' */
  rtB.Mult1[0] = rtB.Integrator[1] * rtB.iqsids[0];
  rtB.Mult1[1] = rtB.Integrator[0] * rtB.iqsids[1];

  /* Sum: '<S17>/Sum2' */
  rtB.Sum2 = rtB.Mult1[0] + rtB.Mult1[1];

  /* Integrator: '<S35>/Rotor angle thetam' */
  rtB.Rotoranglethetam = rtX.Rotoranglethetam_CSTATE;

  /* Gain: '<S35>/1\p' */
  rtb_FromWs = rtP.p_Gain * rtB.Rotoranglethetam;

  /* Gain: '<S35>/Gain' */
  rtb_Gain[0] = rtP.Gain_Gain[0] * rtB.Rotorspeedwm;
  rtb_Gain[1] = rtP.Gain_Gain[1] * rtB.Sum2;
  rtb_Gain[2] = rtP.Gain_Gain[2] * rtb_FromWs;

  /* FromWorkspace: '<S3>/FromWs' */
  {
    real_T *pDataValues = (real_T *) rtDW.FromWs_PWORK.DataPtr;
    real_T *pTimeValues = (real_T *) rtDW.FromWs_PWORK.TimePtr;
    int_T currTimeIndex = rtDW.FromWs_IWORK.PrevIndex;
    real_T t = ssGetTaskTime(rtS,0);
    int numPoints, lastPoint;
    FWksInfo *fromwksInfo = (FWksInfo *) rtDW.FromWs_PWORK.RSimInfoPtr;
    numPoints = fromwksInfo->nDataPoints;
    lastPoint = numPoints - 1;

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[lastPoint]) {
      currTimeIndex = lastPoint-1;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    rtDW.FromWs_IWORK.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          rtb_FromWs = pDataValues[currTimeIndex];
        } else {
          rtb_FromWs = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;
        int_T* zcTimeIndices = &rtDW.FromWs_ZCTimeIndices[0];
        int_T *zcTimeIndicesIdx = &rtDW.FromWs_CurZCTimeIndIdx;
        int_T zcIdx = zcTimeIndices[*zcTimeIndicesIdx];
        int_T numZcTimes = 2;
        if (*zcTimeIndicesIdx < numZcTimes) {
          if (ssIsMajorTimeStep(rtS) ) {
            if (t > pTimeValues[zcIdx]) {
              while (*zcTimeIndicesIdx < (numZcTimes-1) &&
                     (t > pTimeValues[zcIdx]) ) {
                (*zcTimeIndicesIdx)++;
                zcIdx = zcTimeIndices[*zcTimeIndicesIdx];
              }
            }
          } else {
            if (t >= pTimeValues[zcIdx] && (ssGetTimeOfLastOutput(rtS) <
                 pTimeValues[zcIdx])) {
              t2 = pTimeValues[zcIdx];
              if (zcIdx == 0) {
                TimeIndex = 0;
                t1 = t2 - 1;
              } else {
                t1 = pTimeValues[zcIdx-1];
                TimeIndex = zcIdx - 1 ;
              }

              f1 = (t2 - t) / (t2 - t1);
              f2 = 1.0 - f1;
            }
          }
        }

        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        if (zcIdx == 0) {
          d2 = d1;
        }

        rtb_FromWs = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += numPoints;
      }
    }
  }

  /* Gain: '<Root>/rpm' */
  rtb_Sum2 = rtP.rpm_Gain * rtb_Gain[0];

  /* Outputs for Enabled SubSystem: '<S16>/sin(thr),cos(thr)' incorporates:
   *  EnablePort: '<S32>/Enable'
   */
  if (ssIsSampleHit(rtS, 1, 0) && ssIsMajorTimeStep(rtS)) {
    /* Constant: '<S16>/Constant' */
    if (rtP.Constant_Value_cs) {
      if (!rtDW.sinthrcosthr_MODE) {
        if (ssGetTaskTime(rtS,1) != ssGetTStart(rtS)) {
          ssSetSolverNeedsReset(rtS);
        }

        rtDW.sinthrcosthr_MODE = true;
      }
    } else {
      if (rtDW.sinthrcosthr_MODE) {
        ssSetSolverNeedsReset(rtS);

        /* Disable for Outport: '<S32>/sin(thr),cos(thr)' */
        rtB.TrigonometricFunction_i = rtP.sinthrcosthr_Y0;
        rtB.TrigonometricFunction1_c = rtP.sinthrcosthr_Y0;
        rtB.Constant_c[0] = rtP.sinthrcosthr_Y0;
        rtB.Constant_c[1] = rtP.sinthrcosthr_Y0;

        /* Disable for Outport: '<S32>/W' */
        for (i = 0; i < 16; i++) {
          rtB.W21wr[i] = rtP.W_Y0_d;
        }

        /* End of Disable for Outport: '<S32>/W' */
        rtDW.sinthrcosthr_MODE = false;
      }
    }

    /* End of Constant: '<S16>/Constant' */
  }

  if (rtDW.sinthrcosthr_MODE) {
    if (ssIsSampleHit(rtS, 1, 0)) {
      /* Constant: '<S32>/Constant' */
      rtB.Constant_c[0] = rtP.Constant_Value[0];
      rtB.Constant_c[1] = rtP.Constant_Value[1];
    }

    /* Gain: '<S32>/Gain1' */
    rtB.Gain1_i = rtP.Gain1_Gain * rtB.Rotorspeedwm;

    /* Trigonometry: '<S32>/Trigonometric Function' */
    rtB.TrigonometricFunction_i = sin(rtB.Rotoranglethetam);

    /* Trigonometry: '<S32>/Trigonometric Function1' */
    rtB.TrigonometricFunction1_c = cos(rtB.Rotoranglethetam);

    /* Assignment: '<S32>/W(1,2)=wr' incorporates:
     *  Constant: '<S32>/u1'
     */
    memcpy(&rtb_Lminrows13col13[0], &rtP.u1_Value_e[0], sizeof(real_T) << 4U);
    rtb_Lminrows13col13[4] = rtB.Rotorspeedwm;

    /* Assignment: '<S32>/W(2,1)=-wr' */
    memcpy(&rtB.W21wr[0], &rtb_Lminrows13col13[0], sizeof(real_T) << 4U);
    rtB.W21wr[1] = rtB.Gain1_i;
  }

  /* End of Outputs for SubSystem: '<S16>/sin(thr),cos(thr)' */

  /* Outputs for Enabled SubSystem: '<S16>/sin(thr),cos(thr)1' incorporates:
   *  EnablePort: '<S33>/Enable'
   */
  if (ssIsSampleHit(rtS, 1, 0) && ssIsMajorTimeStep(rtS)) {
    /* Constant: '<S16>/Constant1' */
    if (rtP.Constant1_Value_m) {
      if (!rtDW.sinthrcosthr1_MODE) {
        if (ssGetTaskTime(rtS,1) != ssGetTStart(rtS)) {
          ssSetSolverNeedsReset(rtS);
        }

        rtDW.sinthrcosthr1_MODE = true;
      }
    } else {
      if (rtDW.sinthrcosthr1_MODE) {
        ssSetSolverNeedsReset(rtS);

        /* Disable for Outport: '<S33>/sin(thr),cos(thr)' */
        rtB.TrigonometricFunction = rtP.sinthrcosthr_Y0_f;
        rtB.TrigonometricFunction1 = rtP.sinthrcosthr_Y0_f;
        rtB.Constant[0] = rtP.sinthrcosthr_Y0_f;
        rtB.Constant[1] = rtP.sinthrcosthr_Y0_f;
        rtDW.sinthrcosthr1_MODE = false;
      }
    }

    /* End of Constant: '<S16>/Constant1' */
  }

  if (rtDW.sinthrcosthr1_MODE) {
    if (ssIsSampleHit(rtS, 1, 0)) {
      /* Constant: '<S33>/Constant' */
      rtB.Constant[0] = rtP.Constant_Value_c[0];
      rtB.Constant[1] = rtP.Constant_Value_c[1];
    }

    /* Gain: '<S33>/Gain3' */
    rtB.Gain3 = rtP.Gain3_Gain * rtB.Rotorspeedwm;

    /* Trigonometry: '<S33>/Trigonometric Function' */
    rtB.TrigonometricFunction = sin(rtB.Rotoranglethetam);

    /* Trigonometry: '<S33>/Trigonometric Function1' */
    rtB.TrigonometricFunction1 = cos(rtB.Rotoranglethetam);

    /* Assignment: '<S33>/W(3,4)=-wr' incorporates:
     *  Constant: '<S33>/u4'
     */
    memcpy(&rtb_Lminrows13col13[0], &rtP.u4_Value[0], sizeof(real_T) << 4U);
    rtb_Lminrows13col13[14] = rtB.Gain3;

    /* Assignment: '<S33>/W(4,3)=wr' */
    memcpy(&rtB.W43wr[0], &rtb_Lminrows13col13[0], sizeof(real_T) << 4U);
    rtB.W43wr[11] = rtB.Rotorspeedwm;
  }

  /* End of Outputs for SubSystem: '<S16>/sin(thr),cos(thr)1' */

  /* Outputs for Enabled SubSystem: '<S16>/sin(beta),cos(beta),sin(th),cos(th)' incorporates:
   *  EnablePort: '<S31>/Enable'
   */
  if (ssIsSampleHit(rtS, 1, 0) && ssIsMajorTimeStep(rtS)) {
    /* Constant: '<S16>/Constant3' */
    if (rtP.Constant3_Value_k) {
      if (!rtDW.sinbetacosbetasinthcosth_MODE) {
        if (ssGetTaskTime(rtS,1) != ssGetTStart(rtS)) {
          ssSetSolverNeedsReset(rtS);
        }

        rtDW.sinbetacosbetasinthcosth_MODE = true;
      }
    } else {
      if (rtDW.sinbetacosbetasinthcosth_MODE) {
        ssSetSolverNeedsReset(rtS);
        rtDW.sinbetacosbetasinthcosth_MODE = false;
      }
    }

    /* End of Constant: '<S16>/Constant3' */
  }

  if (rtDW.sinbetacosbetasinthcosth_MODE) {
    /* Clock: '<S31>/Clock' */
    rtb_Clock = ssGetT(rtS);

    /* Sum: '<S31>/Sum' incorporates:
     *  Constant: '<S31>/we'
     */
    rtB.wewr = rtP.we_Value - rtB.Rotorspeedwm;

    /* Gain: '<S31>/Gain2' */
    rtB.Gain2 = rtP.Gain2_Gain * rtB.wewr;

    /* Gain: '<S31>/web_psb' */
    rtB.th = rtP.web_psb_Gain * rtb_Clock;

    /* Sum: '<S31>/Sum1' */
    rtB.beta = rtB.th - rtB.Rotoranglethetam;

    /* Trigonometry: '<S31>/Trigonometric Function' */
    rtB.TrigonometricFunction_b = sin(rtB.th);

    /* Trigonometry: '<S31>/Trigonometric Function1' */
    rtB.TrigonometricFunction1_m = sin(rtB.beta);

    /* Trigonometry: '<S31>/Trigonometric Function2' */
    rtB.TrigonometricFunction2 = cos(rtB.beta);

    /* Trigonometry: '<S31>/Trigonometric Function3' */
    rtB.TrigonometricFunction3 = cos(rtB.th);

    /* Assignment: '<S31>/W(3,4)=1-wr' incorporates:
     *  Constant: '<S31>/u3'
     */
    memcpy(&rtb_Lminrows13col13[0], &rtP.u3_Value[0], sizeof(real_T) << 4U);
    rtb_Lminrows13col13[14] = rtB.wewr;

    /* Assignment: '<S31>/W(4,3)=wr-1' */
    memcpy(&rtB.W43wr1[0], &rtb_Lminrows13col13[0], sizeof(real_T) << 4U);
    rtB.W43wr1[11] = rtB.Gain2;
  }

  /* End of Outputs for SubSystem: '<S16>/sin(beta),cos(beta),sin(th),cos(th)' */

  /* MultiPortSwitch: '<S16>/Multiport Switch' incorporates:
   *  Constant: '<S16>/Constant2'
   */
  switch ((int32_T)rtP.Constant2_Value_h) {
   case 1:
    rtB.MultiportSwitch[0] = rtB.TrigonometricFunction_i;
    rtB.MultiportSwitch[1] = rtB.TrigonometricFunction1_c;
    rtB.MultiportSwitch[2] = rtB.Constant_c[0];
    rtB.MultiportSwitch[3] = rtB.Constant_c[1];
    break;

   case 2:
    rtB.MultiportSwitch[0] = rtB.TrigonometricFunction;
    rtB.MultiportSwitch[1] = rtB.TrigonometricFunction1;
    rtB.MultiportSwitch[2] = rtB.Constant[0];
    rtB.MultiportSwitch[3] = rtB.Constant[1];
    break;

   default:
    rtB.MultiportSwitch[0] = rtB.TrigonometricFunction1_m;
    rtB.MultiportSwitch[1] = rtB.TrigonometricFunction2;
    rtB.MultiportSwitch[2] = rtB.TrigonometricFunction_b;
    rtB.MultiportSwitch[3] = rtB.TrigonometricFunction3;
    break;
  }

  /* End of MultiPortSwitch: '<S16>/Multiport Switch' */

  /* Outputs for Enabled SubSystem: '<S15>/Rotor reference frame' incorporates:
   *  EnablePort: '<S28>/Enable'
   */
  if (ssIsSampleHit(rtS, 1, 0) && ssIsMajorTimeStep(rtS)) {
    /* Constant: '<S15>/Constant' */
    if (rtP.Constant_Value_n) {
      if (!rtDW.Rotorreferenceframe_MODE) {
        if (ssGetTaskTime(rtS,1) != ssGetTStart(rtS)) {
          ssSetSolverNeedsReset(rtS);
        }

        rtDW.Rotorreferenceframe_MODE = true;
      }
    } else {
      if (rtDW.Rotorreferenceframe_MODE) {
        ssSetSolverNeedsReset(rtS);

        /* Disable for Outport: '<S28>/ira,irb' */
        rtB.ira_d = rtP.irairb_Y0;
        rtB.irb_c = rtP.irairb_Y0;

        /* Disable for Outport: '<S28>/isa,isb' */
        rtB.isa_b = rtP.isaisb_Y0;
        rtB.isb_p = rtP.isaisb_Y0;
        rtDW.Rotorreferenceframe_MODE = false;
      }
    }

    /* End of Constant: '<S15>/Constant' */
  }

  if (rtDW.Rotorreferenceframe_MODE) {
    /* Fcn: '<S28>/ira' */
    rtB.ira_d = rtB.Product3[2];

    /* Fcn: '<S28>/irb' */
    rtB.irb_c = -(1.7320508075688772 * rtB.Product3[3] + rtB.Product3[2]) / 2.0;

    /* Fcn: '<S28>/isa' */
    rtB.isa_b = rtB.MultiportSwitch[1] * rtB.Product3[0] + rtB.MultiportSwitch[0]
      * rtB.Product3[1];

    /* Fcn: '<S28>/isb' */
    rtB.isb_p = ((1.7320508075688772 * rtB.MultiportSwitch[0] +
                  -rtB.MultiportSwitch[1]) * rtB.Product3[0] +
                 (-1.7320508075688772 * rtB.MultiportSwitch[1] -
                  rtB.MultiportSwitch[0]) * rtB.Product3[1]) / 2.0;
  }

  /* End of Outputs for SubSystem: '<S15>/Rotor reference frame' */

  /* Outputs for Enabled SubSystem: '<S15>/Stationary reference frame' incorporates:
   *  EnablePort: '<S29>/Enable'
   */
  if (ssIsSampleHit(rtS, 1, 0) && ssIsMajorTimeStep(rtS)) {
    /* Constant: '<S15>/Constant1' */
    if (rtP.Constant1_Value_om) {
      if (!rtDW.Stationaryreferenceframe_MODE) {
        if (ssGetTaskTime(rtS,1) != ssGetTStart(rtS)) {
          ssSetSolverNeedsReset(rtS);
        }

        rtDW.Stationaryreferenceframe_MODE = true;
      }
    } else {
      if (rtDW.Stationaryreferenceframe_MODE) {
        ssSetSolverNeedsReset(rtS);

        /* Disable for Outport: '<S29>/ira,irb' */
        rtB.ira_c = rtP.irairb_Y0_k;
        rtB.irb_o = rtP.irairb_Y0_k;

        /* Disable for Outport: '<S29>/isa,isb' */
        rtB.isa_m = rtP.isaisb_Y0_n;
        rtB.isb_h = rtP.isaisb_Y0_n;
        rtDW.Stationaryreferenceframe_MODE = false;
      }
    }

    /* End of Constant: '<S15>/Constant1' */
  }

  if (rtDW.Stationaryreferenceframe_MODE) {
    /* Fcn: '<S29>/ira' */
    rtB.ira_c = rtB.MultiportSwitch[1] * rtB.Product3[2] - rtB.MultiportSwitch[0]
      * rtB.Product3[3];

    /* Fcn: '<S29>/irb' */
    rtB.irb_o = ((-rtB.MultiportSwitch[1] - 1.7320508075688772 *
                  rtB.MultiportSwitch[0]) * rtB.Product3[2] +
                 (rtB.MultiportSwitch[0] - 1.7320508075688772 *
                  rtB.MultiportSwitch[1]) * rtB.Product3[3]) / 2.0;

    /* Fcn: '<S29>/isa' */
    rtB.isa_m = rtB.Product3[0];

    /* Fcn: '<S29>/isb' */
    rtB.isb_h = -(1.7320508075688772 * rtB.Product3[1] + rtB.Product3[0]) / 2.0;
  }

  /* End of Outputs for SubSystem: '<S15>/Stationary reference frame' */

  /* Outputs for Enabled SubSystem: '<S15>/Synchronous reference frame' incorporates:
   *  EnablePort: '<S30>/Enable'
   */
  if (ssIsSampleHit(rtS, 1, 0) && ssIsMajorTimeStep(rtS)) {
    /* Constant: '<S15>/Constant2' */
    if (rtP.Constant2_Value_d) {
      if (!rtDW.Synchronousreferenceframe_MODE) {
        if (ssGetTaskTime(rtS,1) != ssGetTStart(rtS)) {
          ssSetSolverNeedsReset(rtS);
        }

        rtDW.Synchronousreferenceframe_MODE = true;
      }
    } else {
      if (rtDW.Synchronousreferenceframe_MODE) {
        ssSetSolverNeedsReset(rtS);

        /* Disable for Outport: '<S30>/ira,irb' */
        rtB.ira = rtP.irairb_Y0_j;
        rtB.irb = rtP.irairb_Y0_j;

        /* Disable for Outport: '<S30>/isa,isb' */
        rtB.isa = rtP.isaisb_Y0_c;
        rtB.isb = rtP.isaisb_Y0_c;
        rtDW.Synchronousreferenceframe_MODE = false;
      }
    }

    /* End of Constant: '<S15>/Constant2' */
  }

  if (rtDW.Synchronousreferenceframe_MODE) {
    /* Fcn: '<S30>/ira' */
    rtB.ira = rtB.MultiportSwitch[1] * rtB.Product3[2] + rtB.MultiportSwitch[0] *
      rtB.Product3[3];

    /* Fcn: '<S30>/irb' */
    rtB.irb = ((1.7320508075688772 * rtB.MultiportSwitch[0] +
                -rtB.MultiportSwitch[1]) * rtB.Product3[2] +
               (-1.7320508075688772 * rtB.MultiportSwitch[1] -
                rtB.MultiportSwitch[0]) * rtB.Product3[3]) / 2.0;

    /* Fcn: '<S30>/isa' */
    rtB.isa = rtB.MultiportSwitch[3] * rtB.Product3[0] + rtB.MultiportSwitch[2] *
      rtB.Product3[1];

    /* Fcn: '<S30>/isb' */
    rtB.isb = ((1.7320508075688772 * rtB.MultiportSwitch[2] +
                -rtB.MultiportSwitch[3]) * rtB.Product3[0] +
               (-1.7320508075688772 * rtB.MultiportSwitch[3] -
                rtB.MultiportSwitch[2]) * rtB.Product3[1]) / 2.0;
  }

  /* End of Outputs for SubSystem: '<S15>/Synchronous reference frame' */

  /* MultiPortSwitch: '<S15>/Multiport Switch' incorporates:
   *  Constant: '<S15>/Constant3'
   */
  switch ((int32_T)rtP.Constant3_Value) {
   case 1:
    rtB.MultiportSwitch_k[0] = rtB.ira_d;
    rtB.MultiportSwitch_k[1] = rtB.irb_c;
    break;

   case 2:
    rtB.MultiportSwitch_k[0] = rtB.ira_c;
    rtB.MultiportSwitch_k[1] = rtB.irb_o;
    break;

   default:
    rtB.MultiportSwitch_k[0] = rtB.ira;
    rtB.MultiportSwitch_k[1] = rtB.irb;
    break;
  }

  /* End of MultiPortSwitch: '<S15>/Multiport Switch' */

  /* Sum: '<S15>/Sum2' */
  rtb_Sum2 = (0.0 - rtB.MultiportSwitch_k[0]) - rtB.MultiportSwitch_k[1];

  /* MultiPortSwitch: '<S15>/Multiport Switch1' incorporates:
   *  Constant: '<S15>/Constant4'
   */
  switch ((int32_T)rtP.Constant4_Value) {
   case 1:
    rtB.MultiportSwitch1[0] = rtB.isa_b;
    rtB.MultiportSwitch1[1] = rtB.isb_p;
    break;

   case 2:
    rtB.MultiportSwitch1[0] = rtB.isa_m;
    rtB.MultiportSwitch1[1] = rtB.isb_h;
    break;

   default:
    rtB.MultiportSwitch1[0] = rtB.isa;
    rtB.MultiportSwitch1[1] = rtB.isb;
    break;
  }

  /* End of MultiPortSwitch: '<S15>/Multiport Switch1' */

  /* Gain: '<S15>/ib' */
  rtB.ib[0] = rtP.ib_Gain * rtB.MultiportSwitch_k[0];
  rtB.ib[1] = rtP.ib_Gain * rtB.MultiportSwitch_k[1];
  rtB.ib[2] = rtP.ib_Gain * rtB.MultiportSwitch1[0];
  rtB.ib[3] = rtP.ib_Gain * rtB.MultiportSwitch1[1];

  /* FromWorkspace: '<S8>/FromWs' */
  {
    real_T *pDataValues = (real_T *) rtDW.FromWs_PWORK_b.DataPtr;
    real_T *pTimeValues = (real_T *) rtDW.FromWs_PWORK_b.TimePtr;
    int_T currTimeIndex = rtDW.FromWs_IWORK_p.PrevIndex;
    real_T t = ssGetTaskTime(rtS,0);
    int numPoints, lastPoint;
    FWksInfo *fromwksInfo = (FWksInfo *) rtDW.FromWs_PWORK_b.RSimInfoPtr;
    numPoints = fromwksInfo->nDataPoints;
    lastPoint = numPoints - 1;

    /* Get index */
    if (t <= pTimeValues[0]) {
      currTimeIndex = 0;
    } else if (t >= pTimeValues[lastPoint]) {
      currTimeIndex = lastPoint-1;
    } else {
      if (t < pTimeValues[currTimeIndex]) {
        while (t < pTimeValues[currTimeIndex]) {
          currTimeIndex--;
        }
      } else {
        while (t >= pTimeValues[currTimeIndex + 1]) {
          currTimeIndex++;
        }
      }
    }

    rtDW.FromWs_IWORK_p.PrevIndex = currTimeIndex;

    /* Post output */
    {
      real_T t1 = pTimeValues[currTimeIndex];
      real_T t2 = pTimeValues[currTimeIndex + 1];
      if (t1 == t2) {
        if (t < t1) {
          rtb_peak2rms = pDataValues[currTimeIndex];
        } else {
          rtb_peak2rms = pDataValues[currTimeIndex + 1];
        }
      } else {
        real_T f1 = (t2 - t) / (t2 - t1);
        real_T f2 = 1.0 - f1;
        real_T d1;
        real_T d2;
        int_T TimeIndex= currTimeIndex;
        int_T* zcTimeIndices = &rtDW.FromWs_ZCTimeIndices_c;
        int_T *zcTimeIndicesIdx = &rtDW.FromWs_CurZCTimeIndIdx_f;
        int_T zcIdx = zcTimeIndices[*zcTimeIndicesIdx];
        int_T numZcTimes = 1;
        if (*zcTimeIndicesIdx < numZcTimes) {
          if (ssIsMajorTimeStep(rtS) ) {
            if (t > pTimeValues[zcIdx]) {
              while (*zcTimeIndicesIdx < (numZcTimes-1) &&
                     (t > pTimeValues[zcIdx]) ) {
                (*zcTimeIndicesIdx)++;
                zcIdx = zcTimeIndices[*zcTimeIndicesIdx];
              }
            }
          } else {
            if (t >= pTimeValues[zcIdx] && (ssGetTimeOfLastOutput(rtS) <
                 pTimeValues[zcIdx])) {
              t2 = pTimeValues[zcIdx];
              if (zcIdx == 0) {
                TimeIndex = 0;
                t1 = t2 - 1;
              } else {
                t1 = pTimeValues[zcIdx-1];
                TimeIndex = zcIdx - 1 ;
              }

              f1 = (t2 - t) / (t2 - t1);
              f2 = 1.0 - f1;
            }
          }
        }

        d1 = pDataValues[TimeIndex];
        d2 = pDataValues[TimeIndex + 1];
        if (zcIdx == 0) {
          d2 = d1;
        }

        rtb_peak2rms = (real_T) rtInterpolate(d1, d2, f1, f2);
        pDataValues += numPoints;
      }
    }
  }

  /* Clock: '<Root>/Clock' */
  rtb_Sum2_b = ssGetT(rtS);

  /* Product: '<Root>/Product' incorporates:
   *  Gain: '<Root>/pu2radpersec'
   */
  rtb_MathFunction1_k = rtP.pu2radpersec_Gain * rtb_peak2rms * rtb_Sum2_b;

  /* Math: '<Root>/Math Function' incorporates:
   *  Constant: '<Root>/Constant1'
   */
  rtb_Sum2_b = rt_remd_snf(rtb_Sum2_b, rtP.Constant1_Value_e);

  /* Lookup: '<Root>/Look-Up Table' */
  rtb_Sum2_b = rt_Lookup(rtP.LookUpTable_XData, 4, rtb_Sum2_b,
    rtP.LookUpTable_YData);

  /* Sum: '<Root>/Sum7' incorporates:
   *  Constant: '<Root>/Constant'
   *  Product: '<Root>/Product1'
   *  Sum: '<Root>/Sum6'
   *  Trigonometry: '<Root>/Trigonometric Function'
   */
  rtB.Sum7[0] = sin(rtb_MathFunction1_k + rtP.Constant_Value_a[0]) *
    rtb_peak2rms - rtb_Sum2_b;
  rtB.Sum7[1] = sin(rtb_MathFunction1_k + rtP.Constant_Value_a[1]) *
    rtb_peak2rms - rtb_Sum2_b;
  rtB.Sum7[2] = sin(rtb_MathFunction1_k + rtP.Constant_Value_a[2]) *
    rtb_peak2rms - rtb_Sum2_b;

  /* Relay: '<Root>/RelayA' */
  if (ssIsMajorTimeStep(rtS)) {
    if (rtB.Sum7[0] >= rtP.RelayA_OnVal) {
      rtDW.RelayA_Mode = true;
    } else {
      if (rtB.Sum7[0] <= rtP.RelayA_OffVal) {
        rtDW.RelayA_Mode = false;
      }
    }
  }

  /* Relay: '<Root>/RelayB' */
  if (ssIsMajorTimeStep(rtS)) {
    if (rtB.Sum7[1] >= rtP.RelayB_OnVal) {
      rtDW.RelayB_Mode = true;
    } else {
      if (rtB.Sum7[1] <= rtP.RelayB_OffVal) {
        rtDW.RelayB_Mode = false;
      }
    }
  }

  if (rtDW.RelayB_Mode) {
    rtb_MathFunction1_k = rtP.RelayB_YOn;
  } else {
    rtb_MathFunction1_k = rtP.RelayB_YOff;
  }

  /* End of Relay: '<Root>/RelayB' */
  if (ssIsSampleHit(rtS, 1, 0)) {
    /* Relay: '<Root>/RelayA' */
    if (rtDW.RelayA_Mode) {
      tmp = rtP.RelayA_YOn;
    } else {
      tmp = rtP.RelayA_YOff;
    }

    /* Sum: '<Root>/Sum4' */
    rtB.Sum4 = tmp - rtb_MathFunction1_k;
  }

  /* Relay: '<Root>/RelayC' */
  if (ssIsMajorTimeStep(rtS)) {
    if (rtB.Sum7[2] >= rtP.RelayC_OnVal) {
      rtDW.RelayC_Mode = true;
    } else {
      if (rtB.Sum7[2] <= rtP.RelayC_OffVal) {
        rtDW.RelayC_Mode = false;
      }
    }
  }

  if (ssIsSampleHit(rtS, 1, 0)) {
    /* Relay: '<Root>/RelayC' */
    if (rtDW.RelayC_Mode) {
      tmp = rtP.RelayC_YOn;
    } else {
      tmp = rtP.RelayC_YOff;
    }

    /* Sum: '<Root>/Sum5' */
    rtB.Sum5 = rtb_MathFunction1_k - tmp;
  }

  /* S-Function block: <S36>/State-Space */
  {
    real_T accum;

    /*
     * Compute outputs:
     * ---------------
     */

    /*
     * Chopper parameter will force zero current (y[i])
     * for an open switch.
     */
    real_T *Ds = (real_T*)rtDW.StateSpace_PWORK.DS;
    accum = 0.0;
    accum += *(Ds++) * rtB.ib[2];
    accum += *(Ds++) * rtB.ib[3];
    accum += *(Ds++) * rtB.Sum4;
    accum += *(Ds++) * rtB.Sum5;
    rtB.StateSpace[0] = accum;
    accum = 0.0;
    accum += *(Ds++) * rtB.ib[2];
    accum += *(Ds++) * rtB.ib[3];
    accum += *(Ds++) * rtB.Sum4;
    accum += *(Ds++) * rtB.Sum5;
    rtB.StateSpace[1] = accum;
    accum = 0.0;
    accum += *(Ds++) * rtB.ib[2];
    accum += *(Ds++) * rtB.ib[3];
    accum += *(Ds++) * rtB.Sum4;
    accum += *(Ds++) * rtB.Sum5;
    rtB.StateSpace[2] = accum;
  }

  /* Gain: '<S14>/1_Vb' incorporates:
   *  Constant: '<S27>/Constant6'
   */
  rtB._Vb[0] = rtP._Vb_Gain * rtP.Constant6_Value[0];
  rtB._Vb[1] = rtP._Vb_Gain * rtP.Constant6_Value[1];
  rtB._Vb[2] = rtP._Vb_Gain * rtB.StateSpace[0];
  rtB._Vb[3] = rtP._Vb_Gain * rtB.StateSpace[1];

  /* Outputs for Enabled SubSystem: '<S14>/Rotor reference frame' incorporates:
   *  EnablePort: '<S24>/Enable'
   */
  if (ssIsSampleHit(rtS, 1, 0) && ssIsMajorTimeStep(rtS)) {
    /* Constant: '<S14>/Constant' */
    if (rtP.Constant_Value_j) {
      if (!rtDW.Rotorreferenceframe_MODE_g) {
        if (ssGetTaskTime(rtS,1) != ssGetTStart(rtS)) {
          ssSetSolverNeedsReset(rtS);
        }

        rtDW.Rotorreferenceframe_MODE_g = true;
      }
    } else {
      if (rtDW.Rotorreferenceframe_MODE_g) {
        ssSetSolverNeedsReset(rtS);

        /* Disable for Outport: '<S24>/vqr,vdr' */
        rtB.vqr_b = rtP.vqrvdr_Y0;
        rtB.vdr_ex = rtP.vqrvdr_Y0;

        /* Disable for Outport: '<S24>/vqs,vds' */
        rtB.vqs_mg = rtP.vqsvds_Y0;
        rtB.vds_p = rtP.vqsvds_Y0;
        rtDW.Rotorreferenceframe_MODE_g = false;
      }
    }

    /* End of Constant: '<S14>/Constant' */
  }

  if (rtDW.Rotorreferenceframe_MODE_g) {
    /* Fcn: '<S24>/vdr' */
    rtB.vdr_ex = -0.57735026918962573 * rtB._Vb[1];

    /* Fcn: '<S24>/vds' */
    rtB.vds_p = ((rtB.MultiportSwitch[0] - 1.7320508075688772 *
                  rtB.MultiportSwitch[1]) * rtB._Vb[3] + 2.0 *
                 rtB.MultiportSwitch[0] * rtB._Vb[2]) * 0.33333333333333331;

    /* Fcn: '<S24>/vqr' */
    rtB.vqr_b = (2.0 * rtB._Vb[0] + rtB._Vb[1]) * 0.33333333333333331;

    /* Fcn: '<S24>/vqs' */
    rtB.vqs_mg = ((1.7320508075688772 * rtB.MultiportSwitch[0] +
                   rtB.MultiportSwitch[1]) * rtB._Vb[3] + 2.0 *
                  rtB.MultiportSwitch[1] * rtB._Vb[2]) * 0.33333333333333331;
  }

  /* End of Outputs for SubSystem: '<S14>/Rotor reference frame' */

  /* Outputs for Enabled SubSystem: '<S14>/Stationary reference frame' incorporates:
   *  EnablePort: '<S25>/Enable'
   */
  if (ssIsSampleHit(rtS, 1, 0) && ssIsMajorTimeStep(rtS)) {
    /* Constant: '<S14>/Constant1' */
    if (rtP.Constant1_Value_ox) {
      if (!rtDW.Stationaryreferenceframe_MODE_a) {
        if (ssGetTaskTime(rtS,1) != ssGetTStart(rtS)) {
          ssSetSolverNeedsReset(rtS);
        }

        rtDW.Stationaryreferenceframe_MODE_a = true;
      }
    } else {
      if (rtDW.Stationaryreferenceframe_MODE_a) {
        ssSetSolverNeedsReset(rtS);

        /* Disable for Outport: '<S25>/vqr,vdr' */
        rtB.vqr_j = rtP.vqrvdr_Y0_h;
        rtB.vdr_e = rtP.vqrvdr_Y0_h;

        /* Disable for Outport: '<S25>/vqs,vds' */
        rtB.vqs_m = rtP.vqsvds_Y0_g;
        rtB.vds_o = rtP.vqsvds_Y0_g;
        rtDW.Stationaryreferenceframe_MODE_a = false;
      }
    }

    /* End of Constant: '<S14>/Constant1' */
  }

  if (rtDW.Stationaryreferenceframe_MODE_a) {
    /* Fcn: '<S25>/vdr' */
    rtB.vdr_e = ((-rtB.MultiportSwitch[0] - 1.7320508075688772 *
                  rtB.MultiportSwitch[1]) * rtB._Vb[1] + -2.0 *
                 rtB.MultiportSwitch[0] * rtB._Vb[0]) * 0.33333333333333331;

    /* Fcn: '<S25>/vds' */
    rtB.vds_o = -0.57735026918962573 * rtB._Vb[3];

    /* Fcn: '<S25>/vqr' */
    rtB.vqr_j = ((rtB.MultiportSwitch[1] - 1.7320508075688772 *
                  rtB.MultiportSwitch[0]) * rtB._Vb[1] + 2.0 *
                 rtB.MultiportSwitch[1] * rtB._Vb[0]) * 0.33333333333333331;

    /* Fcn: '<S25>/vqs' */
    rtB.vqs_m = (2.0 * rtB._Vb[2] + rtB._Vb[3]) * 0.33333333333333331;
  }

  /* End of Outputs for SubSystem: '<S14>/Stationary reference frame' */

  /* Outputs for Enabled SubSystem: '<S14>/Synchronous reference frame' incorporates:
   *  EnablePort: '<S26>/Enable'
   */
  if (ssIsSampleHit(rtS, 1, 0) && ssIsMajorTimeStep(rtS)) {
    /* Constant: '<S14>/Constant2' */
    if (rtP.Constant2_Value_e) {
      if (!rtDW.Synchronousreferenceframe_MOD_l) {
        if (ssGetTaskTime(rtS,1) != ssGetTStart(rtS)) {
          ssSetSolverNeedsReset(rtS);
        }

        rtDW.Synchronousreferenceframe_MOD_l = true;
      }
    } else {
      if (rtDW.Synchronousreferenceframe_MOD_l) {
        ssSetSolverNeedsReset(rtS);

        /* Disable for Outport: '<S26>/vqr,vdr' */
        rtB.vqr = rtP.vqrvdr_Y0_m;
        rtB.vdr = rtP.vqrvdr_Y0_m;

        /* Disable for Outport: '<S26>/vqs,vds' */
        rtB.vqs = rtP.vqsvds_Y0_h;
        rtB.vds = rtP.vqsvds_Y0_h;
        rtDW.Synchronousreferenceframe_MOD_l = false;
      }
    }

    /* End of Constant: '<S14>/Constant2' */
  }

  if (rtDW.Synchronousreferenceframe_MOD_l) {
    /* Fcn: '<S26>/vdr' */
    rtB.vdr = ((rtB.MultiportSwitch[0] - 1.7320508075688772 *
                rtB.MultiportSwitch[1]) * rtB._Vb[1] + 2.0 *
               rtB.MultiportSwitch[0] * rtB._Vb[0]) / 3.0;

    /* Fcn: '<S26>/vds' */
    rtB.vds = ((rtB.MultiportSwitch[2] - 1.7320508075688772 *
                rtB.MultiportSwitch[3]) * rtB._Vb[3] + 2.0 *
               rtB.MultiportSwitch[2] * rtB._Vb[2]) / 3.0;

    /* Fcn: '<S26>/vqr' */
    rtB.vqr = ((1.7320508075688772 * rtB.MultiportSwitch[0] +
                rtB.MultiportSwitch[1]) * rtB._Vb[1] + 2.0 *
               rtB.MultiportSwitch[1] * rtB._Vb[0]) / 3.0;

    /* Fcn: '<S26>/vqs' */
    rtB.vqs = ((1.7320508075688772 * rtB.MultiportSwitch[2] +
                rtB.MultiportSwitch[3]) * rtB._Vb[3] + 2.0 *
               rtB.MultiportSwitch[3] * rtB._Vb[2]) / 3.0;
  }

  /* End of Outputs for SubSystem: '<S14>/Synchronous reference frame' */

  /* MultiPortSwitch: '<S14>/Multiport Switch' incorporates:
   *  Constant: '<S14>/Constant3'
   */
  switch ((int32_T)rtP.Constant3_Value_l) {
   case 1:
    rtB.MultiportSwitch_c[0] = rtB.vqr_b;
    rtB.MultiportSwitch_c[1] = rtB.vdr_ex;
    break;

   case 2:
    rtB.MultiportSwitch_c[0] = rtB.vqr_j;
    rtB.MultiportSwitch_c[1] = rtB.vdr_e;
    break;

   default:
    rtB.MultiportSwitch_c[0] = rtB.vqr;
    rtB.MultiportSwitch_c[1] = rtB.vdr;
    break;
  }

  /* End of MultiPortSwitch: '<S14>/Multiport Switch' */

  /* Sum: '<S15>/Sum3' */
  rtb_peak2rms = (0.0 - rtB.MultiportSwitch1[0]) - rtB.MultiportSwitch1[1];

  /* MultiPortSwitch: '<S14>/Multiport Switch1' incorporates:
   *  Constant: '<S14>/Constant4'
   */
  switch ((int32_T)rtP.Constant4_Value_m) {
   case 1:
    rtB.MultiportSwitch1_p[0] = rtB.vqs_mg;
    rtB.MultiportSwitch1_p[1] = rtB.vds_p;
    break;

   case 2:
    rtB.MultiportSwitch1_p[0] = rtB.vqs_m;
    rtB.MultiportSwitch1_p[1] = rtB.vds_o;
    break;

   default:
    rtB.MultiportSwitch1_p[0] = rtB.vqs;
    rtB.MultiportSwitch1_p[1] = rtB.vds;
    break;
  }

  /* End of MultiPortSwitch: '<S14>/Multiport Switch1' */

  /* Switch: '<S13>/Switch2' incorporates:
   *  Constant: '<S13>/Constant5'
   *  Constant: '<S13>/Lm_nosat'
   */
  if (rtP.Constant5_Value >= rtP.Switch2_Threshold) {
    rtb_cosnwt = rtB.Lm;
  } else {
    rtb_cosnwt = rtP.Lm_nosat_Value;
  }

  /* End of Switch: '<S13>/Switch2' */

  /* Gain: '<S12>/unit conversion' */
  rtb_unitconversion[0] = rtP.unitconversion_Gain[0] * rtB.MultiportSwitch_k[0];
  rtb_unitconversion[1] = rtP.unitconversion_Gain[1] * rtB.MultiportSwitch_k[1];
  rtb_unitconversion[2] = rtP.unitconversion_Gain[2] * rtb_Sum2;
  rtb_unitconversion[3] = rtP.unitconversion_Gain[3] * rtB.Product3[2];
  rtb_unitconversion[4] = rtP.unitconversion_Gain[4] * rtB.Product3[3];
  rtb_unitconversion[5] = rtP.unitconversion_Gain[5] * rtB.Integrator[2];
  rtb_unitconversion[6] = rtP.unitconversion_Gain[6] * rtB.Integrator[3];
  rtb_unitconversion[7] = rtP.unitconversion_Gain[7] * rtB.MultiportSwitch_c[0];
  rtb_unitconversion[8] = rtP.unitconversion_Gain[8] * rtB.MultiportSwitch_c[1];
  rtb_unitconversion[9] = rtP.unitconversion_Gain[9] * rtB.MultiportSwitch1[0];
  rtb_unitconversion[10] = rtP.unitconversion_Gain[10] * rtB.MultiportSwitch1[1];
  rtb_unitconversion[11] = rtP.unitconversion_Gain[11] * rtb_peak2rms;
  rtb_unitconversion[12] = rtP.unitconversion_Gain[12] * rtB.Product3[0];
  rtb_unitconversion[13] = rtP.unitconversion_Gain[13] * rtB.Product3[1];
  rtb_unitconversion[14] = rtP.unitconversion_Gain[14] * rtB.Integrator[0];
  rtb_unitconversion[15] = rtP.unitconversion_Gain[15] * rtB.Integrator[1];
  rtb_unitconversion[16] = rtP.unitconversion_Gain[16] * rtB.MultiportSwitch1_p
    [0];
  rtb_unitconversion[17] = rtP.unitconversion_Gain[17] * rtB.MultiportSwitch1_p
    [1];
  rtb_unitconversion[18] = rtP.unitconversion_Gain[18] * rtb_cosnwt;

  /* MultiPortSwitch: '<S16>/Multiport Switch1' incorporates:
   *  Constant: '<S16>/Constant4'
   */
  switch ((int32_T)rtP.Constant4_Value_l) {
   case 1:
    memcpy(&rtb_Lminrows13col13[0], &rtB.W21wr[0], sizeof(real_T) << 4U);
    break;

   case 2:
    memcpy(&rtb_Lminrows13col13[0], &rtB.W43wr[0], sizeof(real_T) << 4U);
    break;

   default:
    memcpy(&rtb_Lminrows13col13[0], &rtB.W43wr1[0], sizeof(real_T) << 4U);
    break;
  }

  for (i = 0; i < 16; i++) {
    /* MultiPortSwitch: '<S16>/Multiport Switch1' */
    rtB.MultiportSwitch1_i[i] = rtb_Lminrows13col13[i];

    /* Switch: '<S13>/Switch1' incorporates:
     *  Constant: '<S13>/Constant3'
     *  Constant: '<S13>/Constant4'
     */
    if (rtP.Constant3_Value_o >= rtP.Switch1_Threshold) {
      rtB.RLinv[i] = rtB.RLinv_p[i];
    } else {
      rtB.RLinv[i] = rtP.Constant4_Value_j[i];
    }

    /* End of Switch: '<S13>/Switch1' */

    /* Sum: '<S13>/Sum1' */
    rtB.A[i] = (0.0 - rtB.MultiportSwitch1_i[i]) - rtB.RLinv[i];
  }

  /* Product: '<S19>/Product1' */
  for (i = 0; i < 4; i++) {
    rtB.Product1[i] = 0.0;
    rtB.Product1[i] += rtB.A[i] * rtB.Integrator[0];
    rtB.Product1[i] += rtB.A[i + 4] * rtB.Integrator[1];
    rtB.Product1[i] += rtB.A[i + 8] * rtB.Integrator[2];
    rtB.Product1[i] += rtB.A[i + 12] * rtB.Integrator[3];
  }

  /* End of Product: '<S19>/Product1' */

  /* Sum: '<S19>/sum1' */
  rtB.sum1[0] = rtB.MultiportSwitch1_p[0] + rtB.Product1[0];
  rtB.sum1[1] = rtB.MultiportSwitch1_p[1] + rtB.Product1[1];
  rtB.sum1[2] = rtB.MultiportSwitch_c[0] + rtB.Product1[2];
  rtB.sum1[3] = rtB.MultiportSwitch_c[1] + rtB.Product1[3];

  /* Gain: '<S19>/wbase' */
  rtB.wbase[0] = rtP.wbase_Gain * rtB.sum1[0];
  rtB.wbase[1] = rtP.wbase_Gain * rtB.sum1[1];
  rtB.wbase[2] = rtP.wbase_Gain * rtB.sum1[2];
  rtB.wbase[3] = rtP.wbase_Gain * rtB.sum1[3];

  /* Gain: '<S35>/1_Tb2' */
  rtB._Tb2 = rtP._Tb2_Gain * rtb_FromWs;

  /* Gain: '<S35>/F' */
  rtB.F = rtP.F_Gain * rtB.Rotorspeedwm;

  /* Sum: '<S35>/Sum' */
  rtB.Sum = (rtB.Sum2 - rtB._Tb2) - rtB.F;

  /* Gain: '<S35>/1_2H' */
  rtB._2H = rtP._2H_Gain * rtB.Sum;

  /* Gain: '<S35>/web_psb' */
  rtB.web_psb = rtP.web_psb_Gain_b * rtB.Rotorspeedwm;

  /* Integrator: '<S2>/integ1' */
  rtB.integ1 = rtX.integ1_CSTATE;

  /* TransportDelay: '<S2>/T' */
  {
    real_T **uBuffer = (real_T**)&rtDW.T_PWORK.TUbufferPtrs[0];
    real_T **tBuffer = (real_T**)&rtDW.T_PWORK.TUbufferPtrs[1];
    real_T simTime = ssGetT(rtS);
    real_T tMinusDelay = simTime - (1.0 / rtP.Fourier_f1);
    rtb_cosnwt = rt_TDelayInterpolate(
      tMinusDelay,
      0.0,
      *tBuffer,
      *uBuffer,
      rtDW.T_IWORK.CircularBufSize,
      &rtDW.T_IWORK.Last,
      rtDW.T_IWORK.Tail,
      rtDW.T_IWORK.Head,
      rtP.T_InitOutput,
      0,
                                      (boolean_T) (ssIsMinorTimeStep(rtS) &&
      (ssGetTimeOfLastOutput(rtS) == ssGetT(rtS))));
  }

  /* Sum: '<S2>/Sum1' */
  rtb_cosnwt = rtB.integ1 - rtb_cosnwt;

  /* Math: '<S2>/Math Function' */
  rtb_MathFunction1_k = rtb_cosnwt * rtb_cosnwt;

  /* Integrator: '<S2>/Integ2' */
  rtB.Integ2 = rtX.Integ2_CSTATE;

  /* TransportDelay: '<S2>/T1' */
  {
    real_T **uBuffer = (real_T**)&rtDW.T1_PWORK.TUbufferPtrs[0];
    real_T **tBuffer = (real_T**)&rtDW.T1_PWORK.TUbufferPtrs[1];
    real_T simTime = ssGetT(rtS);
    real_T tMinusDelay = simTime - (1.0 / rtP.Fourier_f1);
    rtb_Sum2_b = rt_TDelayInterpolate(
      tMinusDelay,
      0.0,
      *tBuffer,
      *uBuffer,
      rtDW.T1_IWORK.CircularBufSize,
      &rtDW.T1_IWORK.Last,
      rtDW.T1_IWORK.Tail,
      rtDW.T1_IWORK.Head,
      rtP.T1_InitOutput,
      0,
                                      (boolean_T) (ssIsMinorTimeStep(rtS) &&
      (ssGetTimeOfLastOutput(rtS) == ssGetT(rtS))));
  }

  /* Sum: '<S2>/Sum2' */
  rtb_Sum2_b = rtB.Integ2 - rtb_Sum2_b;

  /* Sum: '<S2>/Sum' incorporates:
   *  Math: '<S2>/Math Function1'
   */
  rtb_peak2rms = rtb_Sum2_b * rtb_Sum2_b + rtb_MathFunction1_k;

  /* Sqrt: '<S2>/Sqrt' */
  if (ssIsMajorTimeStep(rtS)) {
    if (rtDW.Sqrt_DWORK1 != 0) {
      ssSetSolverNeedsReset(rtS);
      rtDW.Sqrt_DWORK1 = 0;
    }

    rtb_peak2rms = sqrt(rtb_peak2rms);
  } else {
    if (rtb_peak2rms < 0.0) {
      rtb_peak2rms = -sqrt(fabs(rtb_peak2rms));
    } else {
      rtb_peak2rms = sqrt(rtb_peak2rms);
    }

    rtDW.Sqrt_DWORK1 = 1;
  }

  /* End of Sqrt: '<S2>/Sqrt' */

  /* Gain: '<Root>/peak2rms' */
  rtb_peak2rms *= rtP.peak2rms_Gain;

  /* Gain: '<S7>/do not delete this gain' */
  rtB.donotdeletethisgain = rtP.donotdeletethisgain_Gain * rtB.StateSpace[2];

  /* Gain: '<S2>/Gain1' */
  rtB.Gain1 = 2.0 * rtP.Fourier_f1 * rtB.donotdeletethisgain;

  /* Gain: '<S2>/Gain2' incorporates:
   *  Trigonometry: '<S2>/Trigonometric Function'
   */
  rtb_Gain2 = rtP.Gain2_Gain_i * rt_atan2d_snf(rtb_Sum2_b, rtb_cosnwt);

  /* Sin: '<S2>/sin(nwt)' */
  rtb_cosnwt = sin(6.2831853071795862 * rtP.Fourier_n * rtP.Fourier_f1 *
                   ssGetTaskTime(rtS,0) + rtP.sinnwt_Phase) * rtP.sinnwt_Amp +
    rtP.sinnwt_Bias;

  /* Product: '<S2>/Product' */
  rtB.Product = rtb_cosnwt * rtB.Gain1;

  /* Sin: '<S2>/cos(nwt)' */
  rtb_cosnwt = sin(6.2831853071795862 * rtP.Fourier_n * rtP.Fourier_f1 *
                   ssGetTaskTime(rtS,0) + rtP.cosnwt_Phase) * rtP.cosnwt_Amp +
    rtP.cosnwt_Bias;

  /* Product: '<S2>/Product1' */
  rtB.Product1_i = rtB.Gain1 * rtb_cosnwt;
  UNUSED_PARAMETER(tid);
}

/* Update for root system: '<Root>' */
void MdlUpdate(int_T tid)
{
  /* Update for Enabled SubSystem: '<S13>/Saturation' incorporates:
   *  Update for EnablePort: '<S18>/Enable'
   */
  if (rtDW.Saturation_MODE) {
  }

  /* End of Update for SubSystem: '<S13>/Saturation' */
  /* Update for TransportDelay: '<S2>/T' */
  {
    real_T **uBuffer = (real_T**)&rtDW.T_PWORK.TUbufferPtrs[0];
    real_T **tBuffer = (real_T**)&rtDW.T_PWORK.TUbufferPtrs[1];
    real_T simTime = ssGetT(rtS);
    rtDW.T_IWORK.Head = ((rtDW.T_IWORK.Head < (rtDW.T_IWORK.CircularBufSize-1)) ?
                         (rtDW.T_IWORK.Head+1) : 0);
    if (rtDW.T_IWORK.Head == rtDW.T_IWORK.Tail) {
      if (!rt_TDelayUpdateTailOrGrowBuf( &rtDW.T_IWORK.CircularBufSize,
           &rtDW.T_IWORK.Tail, &rtDW.T_IWORK.Head, &rtDW.T_IWORK.Last, simTime -
           (1.0 / rtP.Fourier_f1), tBuffer, uBuffer, (NULL), (boolean_T)0, false,
           &rtDW.T_IWORK.MaxNewBufSize)) {
        ssSetErrorStatus(rtS, "tdelay memory allocation error");
        return;
      }
    }

    (*tBuffer)[rtDW.T_IWORK.Head] = simTime;
    (*uBuffer)[rtDW.T_IWORK.Head] = rtB.integ1;
  }

  /* Update for TransportDelay: '<S2>/T1' */
  {
    real_T **uBuffer = (real_T**)&rtDW.T1_PWORK.TUbufferPtrs[0];
    real_T **tBuffer = (real_T**)&rtDW.T1_PWORK.TUbufferPtrs[1];
    real_T simTime = ssGetT(rtS);
    rtDW.T1_IWORK.Head = ((rtDW.T1_IWORK.Head < (rtDW.T1_IWORK.CircularBufSize-1))
                          ? (rtDW.T1_IWORK.Head+1) : 0);
    if (rtDW.T1_IWORK.Head == rtDW.T1_IWORK.Tail) {
      if (!rt_TDelayUpdateTailOrGrowBuf( &rtDW.T1_IWORK.CircularBufSize,
           &rtDW.T1_IWORK.Tail, &rtDW.T1_IWORK.Head, &rtDW.T1_IWORK.Last,
           simTime - (1.0 / rtP.Fourier_f1), tBuffer, uBuffer, (NULL),
           (boolean_T)0, false, &rtDW.T1_IWORK.MaxNewBufSize)) {
        ssSetErrorStatus(rtS, "tdelay memory allocation error");
        return;
      }
    }

    (*tBuffer)[rtDW.T1_IWORK.Head] = simTime;
    (*uBuffer)[rtDW.T1_IWORK.Head] = rtB.Integ2;
  }

  UNUSED_PARAMETER(tid);
}

/* Derivatives for root system: '<Root>' */
void MdlDerivatives(void)
{
  /* Derivatives for Integrator: '<S35>/Rotor speed (wm)' */
  {
    ((XDot *) ssGetdX(rtS))->Rotorspeedwm_CSTATE = rtB._2H;
  }

  /* Derivatives for Integrator: '<S19>/Integrator' */
  {
    ((XDot *) ssGetdX(rtS))->Integrator_CSTATE[0] = rtB.wbase[0];
    ((XDot *) ssGetdX(rtS))->Integrator_CSTATE[1] = rtB.wbase[1];
    ((XDot *) ssGetdX(rtS))->Integrator_CSTATE[2] = rtB.wbase[2];
    ((XDot *) ssGetdX(rtS))->Integrator_CSTATE[3] = rtB.wbase[3];
  }

  /* Derivatives for Enabled SubSystem: '<S13>/Saturation' */
  if (rtDW.Saturation_MODE) {
    /* Derivatives for Integrator: '<S22>/Integrator' */
    {
      ((XDot *) ssGetdX(rtS))->Integrator_CSTATE_k = rtB.TT1e6s;
    }
  } else {
    ((XDot *) ssGetdX(rtS))->Integrator_CSTATE_k = 0.0;
  }

  /* End of Derivatives for SubSystem: '<S13>/Saturation' */
  /* Derivatives for Integrator: '<S35>/Rotor angle thetam' */
  {
    ((XDot *) ssGetdX(rtS))->Rotoranglethetam_CSTATE = rtB.web_psb;
  }

  /* Derivatives for Integrator: '<S2>/integ1' */
  {
    ((XDot *) ssGetdX(rtS))->integ1_CSTATE = rtB.Product;
  }

  /* Derivatives for Integrator: '<S2>/Integ2' */
  {
    ((XDot *) ssGetdX(rtS))->Integ2_CSTATE = rtB.Product1_i;
  }
}

/* Projection for root system: '<Root>' */
void MdlProjection(void)
{
}

/* ZeroCrossings for root system: '<Root>' */
void MdlZeroCrossings(void)
{
  /* ZeroCrossings for Enabled SubSystem: '<S13>/Saturation' */
  if (rtDW.Saturation_MODE) {
    /* ZeroCrossings for Switch: '<S18>/Switch' */
    ((ZCV *) ssGetSolverZcSignalVector(rtS))->Switch_SwitchCond_ZC = rtB.Isat;
  } else {
    {
      ((ZCV *) ssGetSolverZcSignalVector(rtS))->Switch_SwitchCond_ZC = 0.0;
    }
  }

  /* End of ZeroCrossings for SubSystem: '<S13>/Saturation' */
  /* ZeroCrossings for FromWorkspace: '<S3>/FromWs' */
  {
    const double* timePtr = (double *)rtDW.FromWs_PWORK.TimePtr;
    int_T* zcTimeIndices = &rtDW.FromWs_ZCTimeIndices[0];
    int_T zcTimeIndicesIdx = rtDW.FromWs_CurZCTimeIndIdx;
    ((ZCV *) ssGetSolverZcSignalVector(rtS))->FromWs_repeatedTime_ZC = ssGetT
      (rtS) - timePtr[zcTimeIndices[zcTimeIndicesIdx]];
  }

  /* ZeroCrossings for FromWorkspace: '<S8>/FromWs' */
  {
    const double* timePtr = (double *)rtDW.FromWs_PWORK_b.TimePtr;
    int_T* zcTimeIndices = &rtDW.FromWs_ZCTimeIndices_c;
    int_T zcTimeIndicesIdx = rtDW.FromWs_CurZCTimeIndIdx_f;
    ((ZCV *) ssGetSolverZcSignalVector(rtS))->FromWs_repeatedTime_ZC_h = ssGetT
      (rtS) - timePtr[zcTimeIndices[zcTimeIndicesIdx]];
  }

  /* ZeroCrossings for Relay: '<Root>/RelayA' */
  if (rtDW.RelayA_Mode) {
    ((ZCV *) ssGetSolverZcSignalVector(rtS))->RelayA_RelayZC_ZC = rtB.Sum7[0] -
      rtP.RelayA_OffVal;
  } else {
    ((ZCV *) ssGetSolverZcSignalVector(rtS))->RelayA_RelayZC_ZC = rtB.Sum7[0] -
      rtP.RelayA_OnVal;
  }

  /* End of ZeroCrossings for Relay: '<Root>/RelayA' */

  /* ZeroCrossings for Relay: '<Root>/RelayB' */
  if (rtDW.RelayB_Mode) {
    ((ZCV *) ssGetSolverZcSignalVector(rtS))->RelayB_RelayZC_ZC = rtB.Sum7[1] -
      rtP.RelayB_OffVal;
  } else {
    ((ZCV *) ssGetSolverZcSignalVector(rtS))->RelayB_RelayZC_ZC = rtB.Sum7[1] -
      rtP.RelayB_OnVal;
  }

  /* End of ZeroCrossings for Relay: '<Root>/RelayB' */

  /* ZeroCrossings for Relay: '<Root>/RelayC' */
  if (rtDW.RelayC_Mode) {
    ((ZCV *) ssGetSolverZcSignalVector(rtS))->RelayC_RelayZC_ZC = rtB.Sum7[2] -
      rtP.RelayC_OffVal;
  } else {
    ((ZCV *) ssGetSolverZcSignalVector(rtS))->RelayC_RelayZC_ZC = rtB.Sum7[2] -
      rtP.RelayC_OnVal;
  }

  /* End of ZeroCrossings for Relay: '<Root>/RelayC' */
}

/* Termination for root system: '<Root>' */
void MdlTerminate(void)
{
  /* Terminate for FromWorkspace: '<S3>/FromWs' */
  rt_FREE(rtDW.FromWs_PWORK.RSimInfoPtr);

  /* Terminate for FromWorkspace: '<S8>/FromWs' */
  rt_FREE(rtDW.FromWs_PWORK_b.RSimInfoPtr);

  /* S-Function block: <S36>/State-Space */
  {
    /* Free memory */
    free(rtDW.StateSpace_PWORK.AS);
    free(rtDW.StateSpace_PWORK.BS);
    free(rtDW.StateSpace_PWORK.CS);
    free(rtDW.StateSpace_PWORK.DS);
    free(rtDW.StateSpace_PWORK.DX_COL);
    free(rtDW.StateSpace_PWORK.BD_COL);
    free(rtDW.StateSpace_PWORK.TMP1);
    free(rtDW.StateSpace_PWORK.TMP2);
  }

  /* Terminate for TransportDelay: '<S2>/T' */
  rt_TDelayFreeBuf(rtDW.T_PWORK.TUbufferPtrs[0]);

  /* Terminate for TransportDelay: '<S2>/T1' */
  rt_TDelayFreeBuf(rtDW.T1_PWORK.TUbufferPtrs[0]);
}

/* Function to initialize sizes */
void MdlInitializeSizes(void)
{
  ssSetNumContStates(rtS, 9);          /* Number of continuous states */
  ssSetNumY(rtS, 0);                   /* Number of model outputs */
  ssSetNumU(rtS, 0);                   /* Number of model inputs */
  ssSetDirectFeedThrough(rtS, 0);      /* The model is not direct feedthrough */
  ssSetNumSampleTimes(rtS, 2);         /* Number of sample times */
  ssSetNumBlocks(rtS, 202);            /* Number of blocks */
  ssSetNumBlockIO(rtS, 95);            /* Number of block outputs */
  ssSetNumBlockParams(rtS, 289);       /* Sum of parameter "widths" */
}

/* Function to initialize sample times. */
void MdlInitializeSampleTimes(void)
{
  /* task periods */
  ssSetSampleTime(rtS, 0, 0.0);
  ssSetSampleTime(rtS, 1, 0.0);

  /* task offsets */
  ssSetOffsetTime(rtS, 0, 0.0);
  ssSetOffsetTime(rtS, 1, 1.0);
}

/* Function to register the model */
SimStruct * induction_motor_drive(void)
{
  static struct _ssMdlInfo mdlInfo;
  (void) memset((char *)rtS, 0,
                sizeof(SimStruct));
  (void) memset((char *)&mdlInfo, 0,
                sizeof(struct _ssMdlInfo));
  ssSetMdlInfoPtr(rtS, &mdlInfo);

  /* timing info */
  {
    static time_T mdlPeriod[NSAMPLE_TIMES];
    static time_T mdlOffset[NSAMPLE_TIMES];
    static time_T mdlTaskTimes[NSAMPLE_TIMES];
    static int_T mdlTsMap[NSAMPLE_TIMES];
    static int_T mdlSampleHits[NSAMPLE_TIMES];
    static boolean_T mdlTNextWasAdjustedPtr[NSAMPLE_TIMES];
    static int_T mdlPerTaskSampleHits[NSAMPLE_TIMES * NSAMPLE_TIMES];
    static time_T mdlTimeOfNextSampleHit[NSAMPLE_TIMES];

    {
      int_T i;
      for (i = 0; i < NSAMPLE_TIMES; i++) {
        mdlPeriod[i] = 0.0;
        mdlOffset[i] = 0.0;
        mdlTaskTimes[i] = 0.0;
        mdlTsMap[i] = i;
        mdlSampleHits[i] = 1;
      }
    }

    ssSetSampleTimePtr(rtS, &mdlPeriod[0]);
    ssSetOffsetTimePtr(rtS, &mdlOffset[0]);
    ssSetSampleTimeTaskIDPtr(rtS, &mdlTsMap[0]);
    ssSetTPtr(rtS, &mdlTaskTimes[0]);
    ssSetSampleHitPtr(rtS, &mdlSampleHits[0]);
    ssSetTNextWasAdjustedPtr(rtS, &mdlTNextWasAdjustedPtr[0]);
    ssSetPerTaskSampleHitsPtr(rtS, &mdlPerTaskSampleHits[0]);
    ssSetTimeOfNextSampleHitPtr(rtS, &mdlTimeOfNextSampleHit[0]);
  }

  ssSetSolverMode(rtS, SOLVER_MODE_SINGLETASKING);

  /*
   * initialize model vectors and cache them in SimStruct
   */

  /* block I/O */
  {
    ssSetBlockIO(rtS, ((void *) &rtB));

    {
      int_T i;
      for (i = 0; i < 16; i++) {
        rtB.Linv[i] = 0.0;
      }

      for (i = 0; i < 16; i++) {
        rtB.MultiportSwitch1_i[i] = 0.0;
      }

      for (i = 0; i < 16; i++) {
        rtB.RLinv[i] = 0.0;
      }

      for (i = 0; i < 16; i++) {
        rtB.A[i] = 0.0;
      }

      for (i = 0; i < 16; i++) {
        rtB.W43wr[i] = 0.0;
      }

      for (i = 0; i < 16; i++) {
        rtB.W21wr[i] = 0.0;
      }

      for (i = 0; i < 16; i++) {
        rtB.W43wr1[i] = 0.0;
      }

      for (i = 0; i < 16; i++) {
        rtB.Sum2_c[i] = 0.0;
      }

      for (i = 0; i < 16; i++) {
        rtB.Linv_m[i] = 0.0;
      }

      for (i = 0; i < 16; i++) {
        rtB.RLinv_p[i] = 0.0;
      }

      rtB.Rotorspeedwm = 0.0;
      rtB.Integrator[0] = 0.0;
      rtB.Integrator[1] = 0.0;
      rtB.Integrator[2] = 0.0;
      rtB.Integrator[3] = 0.0;
      rtB.Product3[0] = 0.0;
      rtB.Product3[1] = 0.0;
      rtB.Product3[2] = 0.0;
      rtB.Product3[3] = 0.0;
      rtB.iqsids[0] = 0.0;
      rtB.iqsids[1] = 0.0;
      rtB.Mult1[0] = 0.0;
      rtB.Mult1[1] = 0.0;
      rtB.Sum2 = 0.0;
      rtB.Rotoranglethetam = 0.0;
      rtB.MultiportSwitch[0] = 0.0;
      rtB.MultiportSwitch[1] = 0.0;
      rtB.MultiportSwitch[2] = 0.0;
      rtB.MultiportSwitch[3] = 0.0;
      rtB.MultiportSwitch_k[0] = 0.0;
      rtB.MultiportSwitch_k[1] = 0.0;
      rtB.MultiportSwitch1[0] = 0.0;
      rtB.MultiportSwitch1[1] = 0.0;
      rtB.ib[0] = 0.0;
      rtB.ib[1] = 0.0;
      rtB.ib[2] = 0.0;
      rtB.ib[3] = 0.0;
      rtB.Sum7[0] = 0.0;
      rtB.Sum7[1] = 0.0;
      rtB.Sum7[2] = 0.0;
      rtB.Sum4 = 0.0;
      rtB.Sum5 = 0.0;
      rtB.StateSpace[0] = 0.0;
      rtB.StateSpace[1] = 0.0;
      rtB.StateSpace[2] = 0.0;
      rtB._Vb[0] = 0.0;
      rtB._Vb[1] = 0.0;
      rtB._Vb[2] = 0.0;
      rtB._Vb[3] = 0.0;
      rtB.MultiportSwitch_c[0] = 0.0;
      rtB.MultiportSwitch_c[1] = 0.0;
      rtB.MultiportSwitch1_p[0] = 0.0;
      rtB.MultiportSwitch1_p[1] = 0.0;
      rtB.Product1[0] = 0.0;
      rtB.Product1[1] = 0.0;
      rtB.Product1[2] = 0.0;
      rtB.Product1[3] = 0.0;
      rtB.sum1[0] = 0.0;
      rtB.sum1[1] = 0.0;
      rtB.sum1[2] = 0.0;
      rtB.sum1[3] = 0.0;
      rtB.wbase[0] = 0.0;
      rtB.wbase[1] = 0.0;
      rtB.wbase[2] = 0.0;
      rtB.wbase[3] = 0.0;
      rtB._Tb2 = 0.0;
      rtB.F = 0.0;
      rtB.Sum = 0.0;
      rtB._2H = 0.0;
      rtB.web_psb = 0.0;
      rtB.integ1 = 0.0;
      rtB.Integ2 = 0.0;
      rtB.donotdeletethisgain = 0.0;
      rtB.Gain1 = 0.0;
      rtB.Product = 0.0;
      rtB.Product1_i = 0.0;
      rtB.Constant[0] = 0.0;
      rtB.Constant[1] = 0.0;
      rtB.Gain3 = 0.0;
      rtB.TrigonometricFunction = 0.0;
      rtB.TrigonometricFunction1 = 0.0;
      rtB.Constant_c[0] = 0.0;
      rtB.Constant_c[1] = 0.0;
      rtB.Gain1_i = 0.0;
      rtB.TrigonometricFunction_i = 0.0;
      rtB.TrigonometricFunction1_c = 0.0;
      rtB.wewr = 0.0;
      rtB.Gain2 = 0.0;
      rtB.th = 0.0;
      rtB.beta = 0.0;
      rtB.TrigonometricFunction_b = 0.0;
      rtB.TrigonometricFunction1_m = 0.0;
      rtB.TrigonometricFunction2 = 0.0;
      rtB.TrigonometricFunction3 = 0.0;
      rtB.ira = 0.0;
      rtB.irb = 0.0;
      rtB.isa = 0.0;
      rtB.isb = 0.0;
      rtB.ira_c = 0.0;
      rtB.irb_o = 0.0;
      rtB.isa_m = 0.0;
      rtB.isb_h = 0.0;
      rtB.ira_d = 0.0;
      rtB.irb_c = 0.0;
      rtB.isa_b = 0.0;
      rtB.isb_p = 0.0;
      rtB.vdr = 0.0;
      rtB.vds = 0.0;
      rtB.vqr = 0.0;
      rtB.vqs = 0.0;
      rtB.vdr_e = 0.0;
      rtB.vds_o = 0.0;
      rtB.vqr_j = 0.0;
      rtB.vqs_m = 0.0;
      rtB.vdr_ex = 0.0;
      rtB.vds_p = 0.0;
      rtB.vqr_b = 0.0;
      rtB.vqs_mg = 0.0;
      rtB.Integrator_g = 0.0;
      rtB.TmpSignalConversionAtMathFuncti[0] = 0.0;
      rtB.TmpSignalConversionAtMathFuncti[1] = 0.0;
      rtB.TmpSignalConversionAtMathFuncti[2] = 0.0;
      rtB.Sum2_f = 0.0;
      rtB.Product2[0] = 0.0;
      rtB.Product2[1] = 0.0;
      rtB.Product_a[0] = 0.0;
      rtB.Product_a[1] = 0.0;
      rtB.phimq = 0.0;
      rtB.Product1_ia[0] = 0.0;
      rtB.Product1_ia[1] = 0.0;
      rtB.phimd = 0.0;
      rtB.Isat = 0.0;
      rtB.Lm = 0.0;
      rtB.Add = 0.0;
      rtB.TT1e6s = 0.0;
      rtB.Lm_e = 0.0;
    }
  }

  /* parameters */
  ssSetDefaultParam(rtS, (real_T *) &rtP);

  /* states (continuous)*/
  {
    real_T *x = (real_T *) &rtX;
    ssSetContStates(rtS, x);
    (void) memset((void *)x, 0,
                  sizeof(X));
  }

  /* states (dwork) */
  {
    void *dwork = (void *) &rtDW;
    ssSetRootDWork(rtS, dwork);
    (void) memset(dwork, 0,
                  sizeof(DW));

    {
      int_T i;
      for (i = 0; i < 16; i++) {
        rtDW.inversion_DWORK4[i] = 0.0;
      }
    }

    rtDW.T_RWORK.modelTStart = 0.0;
    rtDW.T1_RWORK.modelTStart = 0.0;
  }

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    ssSetModelMappingInfo(rtS, &dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  /* Model specific registration */
  ssSetRootSS(rtS, rtS);
  ssSetVersion(rtS, SIMSTRUCT_VERSION_LEVEL2);
  ssSetModelName(rtS, "induction_motor_drive");
  ssSetPath(rtS, "induction_motor_drive");
  ssSetTStart(rtS, 0.0);
  ssSetTFinal(rtS, 2.0);

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    ssSetRTWLogInfo(rtS, &rt_DataLoggingInfo);
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(ssGetRTWLogInfo(rtS), (NULL));
    rtliSetLogXSignalPtrs(ssGetRTWLogInfo(rtS), (NULL));
    rtliSetLogT(ssGetRTWLogInfo(rtS), "t");
    rtliSetLogX(ssGetRTWLogInfo(rtS), "");
    rtliSetLogXFinal(ssGetRTWLogInfo(rtS), "");
    rtliSetLogVarNameModifier(ssGetRTWLogInfo(rtS), "rt_");
    rtliSetLogFormat(ssGetRTWLogInfo(rtS), 0);
    rtliSetLogMaxRows(ssGetRTWLogInfo(rtS), 0);
    rtliSetLogDecimation(ssGetRTWLogInfo(rtS), 1);
    rtliSetLogY(ssGetRTWLogInfo(rtS), "");
    rtliSetLogYSignalInfo(ssGetRTWLogInfo(rtS), (NULL));
    rtliSetLogYSignalPtrs(ssGetRTWLogInfo(rtS), (NULL));
  }

  {
    static struct _ssStatesInfo2 statesInfo2;
    ssSetStatesInfo2(rtS, &statesInfo2);
  }

  {
    static ssSolverInfo slvrInfo;
    static boolean_T contStatesDisabled[9];
    static real_T absTol[9] = { 1.0E-6, 1.0E-6, 1.0E-6, 1.0E-6, 1.0E-6, 1.0E-6,
      1.0E-6, 1.0E-6, 1.0E-6 };

    static uint8_T absTolControl[9] = { 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U };

    static uint8_T zcAttributes[6] = { (ZC_EVENT_ALL_UP), (ZC_EVENT_ALL_UP),
      (ZC_EVENT_ALL), (ZC_EVENT_ALL), (ZC_EVENT_ALL), (ZC_EVENT_ALL) };

    static ssNonContDerivSigInfo nonContDerivSigInfo[2] = {
      { 1*sizeof(real_T), (char*)(&rtB.Sum5), (NULL) }
      , { 1*sizeof(real_T), (char*)(&rtB.Sum4), (NULL) }
    };

    ssSetSolverRelTol(rtS, 0.0001);
    ssSetStepSize(rtS, 0.0);
    ssSetMinStepSize(rtS, 0.0);
    ssSetMaxNumMinSteps(rtS, -1);
    ssSetMinStepViolatedError(rtS, 0);
    ssSetMaxStepSize(rtS, 1.0E-5);
    ssSetSolverMaxOrder(rtS, -1);
    ssSetSolverRefineFactor(rtS, 1);
    ssSetOutputTimes(rtS, (NULL));
    ssSetNumOutputTimes(rtS, 0);
    ssSetOutputTimesOnly(rtS, 0);
    ssSetOutputTimesIndex(rtS, 0);
    ssSetZCCacheNeedsReset(rtS, 0);
    ssSetDerivCacheNeedsReset(rtS, 0);
    ssSetNumNonContDerivSigInfos(rtS, 2);
    ssSetNonContDerivSigInfos(rtS, nonContDerivSigInfo);
    ssSetSolverInfo(rtS, &slvrInfo);
    ssSetSolverName(rtS, "ode23t");
    ssSetVariableStepSolver(rtS, 1);
    ssSetSolverConsistencyChecking(rtS, 0);
    ssSetSolverAdaptiveZcDetection(rtS, 0);
    ssSetSolverRobustResetMethod(rtS, 0);
    ssSetAbsTolVector(rtS, absTol);
    ssSetAbsTolControlVector(rtS, absTolControl);
    ssSetSolverAbsTol_Obsolete(rtS, absTol);
    ssSetSolverAbsTolControl_Obsolete(rtS, absTolControl);
    ssSetSolverStateProjection(rtS, 0);
    ssSetSolverMassMatrixType(rtS, (ssMatrixType)0);
    ssSetSolverMassMatrixNzMax(rtS, 0);
    ssSetModelOutputs(rtS, MdlOutputs);
    ssSetModelLogData(rtS, rt_UpdateTXYLogVars);
    ssSetModelUpdate(rtS, MdlUpdate);
    ssSetModelDerivatives(rtS, MdlDerivatives);
    ssSetSolverZcSignalAttrib(rtS, zcAttributes);
    ssSetSolverNumZcSignals(rtS, 6);
    ssSetModelZeroCrossings(rtS, MdlZeroCrossings);
    ssSetSolverConsecutiveZCsStepRelTol(rtS, 2.8421709430404007E-13);
    ssSetSolverMaxConsecutiveZCs(rtS, 1000);
    ssSetSolverConsecutiveZCsError(rtS, 2);
    ssSetSolverMaskedZcDiagnostic(rtS, 1);
    ssSetSolverIgnoredZcDiagnostic(rtS, 1);
    ssSetSolverMaxConsecutiveMinStep(rtS, 1);
    ssSetSolverShapePreserveControl(rtS, 2);
    ssSetTNextTid(rtS, INT_MIN);
    ssSetTNext(rtS, rtMinusInf);
    ssSetSolverNeedsReset(rtS);
    ssSetNumNonsampledZCs(rtS, 6);
    ssSetContStateDisabled(rtS, contStatesDisabled);
    ssSetSolverMaxConsecutiveMinStep(rtS, 1);
  }

  ssSetChecksumVal(rtS, 0, 3736795049U);
  ssSetChecksumVal(rtS, 1, 3895000086U);
  ssSetChecksumVal(rtS, 2, 2409864627U);
  ssSetChecksumVal(rtS, 3, 1052769672U);
  return rtS;
}
